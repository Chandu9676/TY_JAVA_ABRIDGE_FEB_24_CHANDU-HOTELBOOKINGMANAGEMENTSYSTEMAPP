package com.capgemini.HotelBookingManagement.service;

import java.util.Scanner;
import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.dao.BookingDAO;
import com.capgemini.HotelBookingManagement.dao.CustomerDAO;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class ServiceCustomerImpl implements ServiceCustomer {

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);

	public boolean getCustromerRegistration(CutomerInfoBean customerinfobean) {

		P: do {

			logger.info("1.Login(Already have an account)");
			logger.info("2.Registration(New Customer)");
			logger.info("3.Home");

			String selection = sc.nextLine();

			while (!inputvalidation.selectinValidation(selection)) {
				logger.info("please enter valid choice (1-3) ");
				selection = sc.nextLine();
			}
			int select = Integer.parseInt(selection);
			switch (select) {
			case 1:
				BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();
				CustomerDAO customerdaoimpl1 = HotelBookingFactory.getCustomerImplInstance();
				boolean values = customerdaoimpl1.getLogin();
				if (values == true) {
					Y: do {
						logger.info("select option bellow");
						logger.info("1.New Bookings");
						logger.info("2.Check Bookings");
						logger.info("3.Upadate Details");
						logger.info("4.Logout");
						String choose = sc.nextLine();
						while (!inputvalidation.choiceValidate(choose)) {
							logger.info("please enter valid choice (1-4) ");
							choose = sc.nextLine();
						}
						int sel = Integer.parseInt(choose);
						switch (sel) {

						case 1:
							customerdaoimpl1.startBooking();
							break;

						case 2:
							bookingdao.getBookingDetailsforCustomer();
							break;

						case 3:
							customerdaoimpl1.updateCustomer(new CutomerInfoBean());
							break;
						case 4:
							logger.info("Logout Successful");
							break Y;

						}

					} while (true);

				}
				break;

			case 2:

				CustomerDAO customerdaoimpl = HotelBookingFactory.getCustomerImplInstance();
				customerdaoimpl.getRegistration(customerinfobean);

				break;
			case 3:
				break P;

			}

		} while (true);

		return true;
	}

}
