package com.capgemini.HotelBookingManagement.exceptions;

@SuppressWarnings("serial")
public class DetailsNotFoundException extends Exception {

	String msg = "Details Not Found";

	public String getMessage() {
		return msg;

	}

}
