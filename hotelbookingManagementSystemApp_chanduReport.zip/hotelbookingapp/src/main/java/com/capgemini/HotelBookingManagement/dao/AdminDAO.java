package com.capgemini.HotelBookingManagement.dao;

public interface AdminDAO {

	public boolean getAdminLogin() throws Exception;

	public boolean getEmployeeOparations();

	public boolean getHotelOparations();

	public boolean getRoomsOparations();

	public boolean getReportsOparations();

}
