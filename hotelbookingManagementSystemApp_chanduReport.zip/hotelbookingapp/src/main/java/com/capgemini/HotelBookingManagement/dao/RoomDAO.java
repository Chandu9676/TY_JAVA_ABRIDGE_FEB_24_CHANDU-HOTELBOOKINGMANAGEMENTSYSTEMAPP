package com.capgemini.HotelBookingManagement.dao;

import java.util.List;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;

public interface RoomDAO {

	public boolean addRoom(RoomInfoBean room);

	public boolean updateRoom(RoomInfoBean room);

	public boolean deleteRoom();

	public List<RoomInfoBean> getAllRooms();

	public boolean roomsCheckingAvailability(String hname);

	public boolean roomSelection(String hname);

	public boolean setRoomUpdate(int roomNo);

	public boolean getRoomDetails();

}
