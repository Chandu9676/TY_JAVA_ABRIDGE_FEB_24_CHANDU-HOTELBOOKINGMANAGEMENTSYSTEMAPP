package com.capgemini.HotelBookingManagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.exceptions.DetailsNotFoundException;
import com.capgemini.HotelBookingManagement.exceptions.EmployeesNotFoundException;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class EmployeeManagementDAOImpl implements EmployeeManagementDAO {

	static List<EmployeeInfoBean> employees = new ArrayList<EmployeeInfoBean>();

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);

	static {
		EmployeeInfoBean employee1 = HotelBookingFactory.getEmployeeInfoBeanInstance();
		employee1.setEmployeeID("1234");
		employee1.setEmployeeName("Aravind kumar");
		employee1.setEmployeePosition("Manager");
		employee1.setEmployeeMobile(9494119938l);
		employee1.setEmployeesalary(25000);
		employee1.setPassword("Aravind@111");
		employee1.setEmployeeMail("aravind111@gmail.com");
		employee1.setEmployeeAge(26);

		EmployeeInfoBean employee2 = HotelBookingFactory.getEmployeeInfoBeanInstance();
		employee2.setEmployeeID("1235");
		employee2.setEmployeeName("Bharath chinna");
		employee2.setEmployeePosition("Accontant");
		employee2.setEmployeeMobile(9524252521l);
		employee2.setEmployeesalary(25000);
		employee2.setPassword("Bharath222@");
		employee2.setEmployeeMail("bharath222@gmail.com");
		employee2.setEmployeeAge(26);

		EmployeeInfoBean employee3 = HotelBookingFactory.getEmployeeInfoBeanInstance();
		employee3.setEmployeeID("1236");
		employee3.setEmployeeName("Akhil burra");
		employee3.setEmployeePosition("Receptionist");
		employee3.setEmployeeMobile(9524212521l);
		employee3.setEmployeesalary(28000);
		employee3.setPassword("Akhil@333");
		employee3.setEmployeeMail("akhilburra333@gmail.com");
		employee3.setEmployeeAge(26);

		EmployeeInfoBean employee4 = HotelBookingFactory.getEmployeeInfoBeanInstance();
		employee4.setEmployeeID("1237");
		employee4.setEmployeeName("Sai kiran");
		employee4.setEmployeePosition("Maintainer");
		employee4.setEmployeeMobile(9587872521l);
		employee4.setEmployeesalary(29000);
		employee4.setPassword("Sai@444");
		employee4.setEmployeeMail("saikiran444@gmail.com");
		employee4.setEmployeeAge(26);

		EmployeeInfoBean employee5 = HotelBookingFactory.getEmployeeInfoBeanInstance();
		employee5.setEmployeeID("1238");
		employee5.setEmployeeName("Aravind golla");
		employee5.setEmployeePosition("Accountant");
		employee5.setEmployeeMobile(9522222521l);
		employee5.setEmployeesalary(26000);
		employee5.setPassword("Aravind555@");
		employee5.setEmployeeMail("bharath000@gmail.com");
		employee5.setEmployeeAge(26);

		employees.add(employee1);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		employees.add(employee5);
	}

	public boolean getEmployeeLogin() {
		logger.info("Employee ID :");
		String employeeID = sc.nextLine();
		while (!inputvalidation.idValidation(employeeID)) {
			logger.info("please enter valid id format should be [4-5 digits]");
			employeeID = sc.nextLine();
		}

		logger.info("Password :");
		String password = sc.nextLine();
		while (!inputvalidation.passwordValidate(password)) {
			logger.info("please enter valid password should be like [abcd@123]");
			password = sc.nextLine();
		}

		int count = 0;
		for (EmployeeInfoBean employeeinfobean : employees) {
			if (employeeinfobean.getEmployeeID().equals(employeeID)
					&& employeeinfobean.getPassword().equals(password)) {
				count++;
			}
		}

		if (count == 1) {
			logger.info("Login Successful");
			return true;

		} else {
			logger.info("------- Login Fail -------");
			logger.info("Login deatails not matched please Re-Login");

			return false;
		}

	}

	public boolean getCustomerOperations() {
		CustomerDAO customerdao = HotelBookingFactory.getCustomerImplInstance();

		S: do {
			logger.info("Select Options bellow ");
			logger.info("1.Get Customer");
			logger.info("2.GetAll Customers ");
			logger.info("3.back");

			String chooseNo = sc.nextLine();
			while (!inputvalidation.selectinValidation(chooseNo)) {
				logger.info("please enter valid choice [1-3]");
				chooseNo = sc.nextLine();
			}

			int chooseNum = Integer.parseInt(chooseNo);
			switch (chooseNum) {

			case 1:
				customerdao.getCustomer();
				break;
			case 2:
				customerdao.getAllCustomers();
				break;
			case 3:
				break S;
			}

		} while (true);

		return true;

	}

	public boolean getBookingOperations() {
		BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();

		T: do {
			logger.info("Select Options bellow ");
			logger.info("1.Get Booking");
			logger.info("2.GetAll Bookings ");
			logger.info("3.back");

			String chooseNumber = sc.nextLine();
			while (!inputvalidation.selectinValidation(chooseNumber)) {
				logger.info("please enter valid choice [1-3]");
				chooseNumber = sc.nextLine();
			}

			int number = Integer.parseInt(chooseNumber);

			switch (number) {
			case 1:
				bookingdao.getBookingDetailsByEmployee();
				break;
			case 2:
				bookingdao.getAllBookingsDetails();
				break;
			case 3:
				break T;
			}

		} while (true);

		return true;

	}

	public boolean addEmployee(EmployeeInfoBean employeesInfo) {

		logger.info("Enter employee ID");
		String ID = sc.nextLine();
		while (!inputvalidation.idValidation(ID)) {
			logger.info("please enter valid id should be [4-5 digits]");
			ID = sc.nextLine();
		}
		for (EmployeeInfoBean employeeinfobean : employees) {
			while (employeeinfobean.getEmployeeID().equals(ID)) {
				logger.info("This Id Already used Try Different");
				ID = sc.nextLine();
				while (!inputvalidation.idValidation(ID)) {
					logger.info("please enter valid id farmat should be [4-5 digits]");
					ID = sc.nextLine();
				}
			}
		}

		logger.info("Enter employee Name");
		String employeeName = sc.nextLine();
		while (!inputvalidation.userNameValidation(employeeName)) {
			logger.info("please enter valid name should be like [First name only]");
			employeeName = sc.nextLine();
		}

		logger.info("Enter employee Job position");
		String job = sc.nextLine();
		while (!inputvalidation.nameValidation(job)) {
			logger.info("please enter valid name should be like [Accountant 4-15 characters]");
			job = sc.nextLine();
		}

		logger.info("Enter employee mobileNumber");
		String mno = sc.nextLine();
		while (!inputvalidation.contactValidation(mno)) {
			logger.info("please enter valid mobile number [10-digits]");
			mno = sc.nextLine();
		}
		long number = Long.parseLong(mno);

		logger.info("Enter employee Salary");
		String salary = sc.nextLine();
		while (!inputvalidation.salaryValidate(salary)) {
			logger.info("please enter valid salary should be [1-7 digits]");
			salary = sc.nextLine();
		}
		double employeesal = Integer.parseInt(salary);

		logger.info("Enter employee mailID");
		String mailID = sc.nextLine();
		while (!inputvalidation.emailValidation(mailID)) {
			logger.info("please enter valid mail farmat should be [abcd123@gmail.com]");
			mailID = sc.nextLine();
		}

		for (EmployeeInfoBean employeeinfobean : employees) {
			while (employeeinfobean.getEmployeeMail().equals(mailID)) {
				logger.info("This user MAIL Already Exist Try Different mail");
				mailID = sc.nextLine();
				while (!inputvalidation.emailValidation(mailID)) {
					logger.info("please enter valid mail farmat should be [abcd@gmail.com]");
					mailID = sc.nextLine();
				}
			}

		}
		logger.info("Enter employee password");
		String password = sc.nextLine();
		while (!inputvalidation.passwordValidate(password)) {
			logger.info("please enter valid password should be like [Abcd@123]");
			password = sc.nextLine();
		}

		logger.info("Enter employee Age");
		String age = sc.nextLine();
		while (!inputvalidation.ageValidation(age)) {
			logger.info("please enter valid Age should be [10-99]");
			age = sc.nextLine();
		}
		int empAge = Integer.parseInt(age);
		employeesInfo.setEmployeeID(ID);
		employeesInfo.setEmployeeName(employeeName);
		employeesInfo.setEmployeePosition(job);
		employeesInfo.setEmployeeMobile(number);
		employeesInfo.setEmployeesalary(employeesal);
		employeesInfo.setPassword(password);
		employeesInfo.setEmployeeMail(mailID);
		employeesInfo.setEmployeeAge(empAge);

		int size = employees.size();

		employees.add(employeesInfo);

		if (size == employees.size()) {
			logger.info("New Employee Details not added");
			return false;
		} else {
			logger.info("New Employee Details added");
			return true;
		}

	}

	public boolean updateEmployee(EmployeeInfoBean employeeinfo) {
		int countcheck = 0;
		logger.info("Enter employee ID");
		String ID2 = sc.nextLine();
		while (!inputvalidation.idValidation(ID2)) {
			logger.info("please enter valid id should be [4-5 digits]");
			ID2 = sc.nextLine();
		}
		for (EmployeeInfoBean employeeinfobean : employees) {
			if (employeeinfobean.getEmployeeID().equals(ID2)) {
				countcheck++;
				logger.info("Enter employee Name");
				String employeeName = sc.nextLine();
				while (!inputvalidation.userNameValidation(employeeName)) {
					logger.info("please enter valid name should be like [first name only]");
					employeeName = sc.nextLine();
				}

				logger.info("Enter employee Job position");
				String job = sc.nextLine();
				while (!inputvalidation.nameValidation(job)) {
					logger.info("please enter valid name should be like [Accountant]");
					job = sc.nextLine();
				}

				logger.info("Enter employee mobileNumber");
				String mno = sc.nextLine();
				while (!inputvalidation.contactValidation(mno)) {
					logger.info("please enter valid mobile number like [10-digits]");
					mno = sc.nextLine();
				}
				long number = Long.parseLong(mno);

				logger.info("Enter employee Salary");
				String salary = sc.nextLine();
				while (!inputvalidation.salaryValidate(salary)) {
					logger.info("please enter valid salary should be [1-7 digits]");
					salary = sc.nextLine();
				}
				double employeesal = Integer.parseInt(salary);

				logger.info("Enter employee mailID");
				String mailID = sc.nextLine();
				while (!inputvalidation.emailValidation(mailID)) {
					logger.info("please enter valid mail farmat should be [abcd123@gmail.com]");
					mailID = sc.nextLine();
				}

				for (EmployeeInfoBean employeeinfobean1 : employees) {
					while (employeeinfobean1.getEmployeeMail().equals(mailID)) {
						logger.info("This user MAIL Already Exist Try Different mail");
						mailID = sc.nextLine();
						while (!inputvalidation.emailValidation(mailID)) {
							logger.info("please enter valid mail farmat should be [abcd1@gmail.com]");
							mailID = sc.nextLine();
						}
					}

				}
				logger.info("Enter employee password");
				String passwords = sc.nextLine();
				while (!inputvalidation.passwordValidate(passwords)) {
					logger.info("please enter valid password should be like [Nani@123]");
					passwords = sc.nextLine();
				}

				logger.info("Enter employee Age");
				String age1 = sc.nextLine();
				while (!inputvalidation.ageValidation(age1)) {
					logger.info("please enter valid Age should be [10-99]");
					age1 = sc.nextLine();
				}
				int empAge = Integer.parseInt(age1);
				employeeinfo.setEmployeeID(ID2);
				employeeinfo.setEmployeeName(employeeName);
				employeeinfo.setEmployeePosition(job);
				employeeinfo.setEmployeeMobile(number);
				employeeinfo.setEmployeesalary(employeesal);
				employeeinfo.setPassword(passwords);
				employeeinfo.setEmployeeMail(mailID);
				employeeinfo.setEmployeeAge(empAge);

			}
		}
		try {
			if (countcheck == 0) {
				throw new EmployeesNotFoundException();
			} else {
				logger.info("details updated successfully");
				return true;
			}
		} catch (EmployeesNotFoundException e) {
			System.err.println(e.getMessage1());
			return false;
		}

	}

	public boolean deleteEmployee() {

		logger.info("Please Enter user ID");
		String employID = sc.nextLine();
		while (!inputvalidation.idValidation(employID)) {
			logger.info("please enter valid id should be [4-5 digits]");
			employID = sc.nextLine();
		}
		int count = 0;

		Iterator<EmployeeInfoBean> employeeBean = employees.iterator();
		while (employeeBean.hasNext()) {

			EmployeeInfoBean str = employeeBean.next();
			if (str.getEmployeeID().equals(employID)) {
				count++;
				logger.info("Id found");
				employeeBean.remove();
			}
		}
		try {
			if (count == 0) {
				throw new EmployeesNotFoundException();
			} else {
				logger.info("data deleted successfully");
				return true;
			}
		} catch (EmployeesNotFoundException e) {
			System.err.println(e.getMessage1());
			return false;
		}

	}

	public boolean getEmployee() {
		logger.info("Please Enter user ID");
		String empID2 = sc.nextLine();
		while (!inputvalidation.idValidation(empID2)) {
			logger.info("please enter valid id should be [4-5 digits]");
			empID2 = sc.nextLine();
		}
		int count1 = 0;
		logger.info("====================================================");
		for (EmployeeInfoBean employeeinfobean : employees) {
			if (employeeinfobean.getEmployeeID().equals(empID2)) {
				logger.info(employeeinfobean);
				count1++;
			}
		}
		try {
			if (count1 == 0) {
				throw new EmployeesNotFoundException();
			} else {
				logger.info("====================================================");
				return true;

			}
		} catch (EmployeesNotFoundException e) {
			System.err.println(e.getMessage1());
			return false;

		}

	}

	public List<EmployeeInfoBean> getAllEmployee() {
		int count = 0;
		logger.info("All Employees are : ");
		logger.info("====================================================");
		for (EmployeeInfoBean employeeinfobean : employees) {
			logger.info(employeeinfobean);
			count++;
		}
		try {
			if (count == 0) {
				throw new EmployeesNotFoundException();
			} else {
				logger.info("====================================================");
			}
		} catch (EmployeesNotFoundException e) {
			System.out.println(e.getMessage1());
		}
		return employees;

	}

}
