package com.capgemini.HotelBookingManagement.validation;

public interface InputValidations {

	public boolean choiceValidate(String choice);

	public boolean idValidation(String iD);

	public boolean nameValidation(String name);

	public boolean userNameValidation(String userName);

	public boolean emailValidation(String email);

	public boolean passwordValidate(String salary);

	public boolean contactValidation(String contactNumber);

	public boolean ageValidation(String age);

	public boolean selectinValidation(String selection);

	public boolean selectionsValidation(String selection);

	public boolean dateValidation(String date);

	public boolean salaryValidate(String salary);

	public boolean fullNameValidate(String name);

	public boolean rmNumberValidate(String no);

	public boolean addressValidate(String addres);

	public boolean roomtypeValidate(String type);

	public boolean cardValidate(String name);

	public boolean cvvValidate(String no);

	public boolean oTPValidate(String addres);

	public boolean hotelCodeValidate(String nor);
	
	public boolean hotelNumberValidate(String no);
	
	public boolean discValidate(String addres);
}
