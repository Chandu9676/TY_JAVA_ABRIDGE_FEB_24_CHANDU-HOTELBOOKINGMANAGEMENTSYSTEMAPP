package com.capgemini.HotelBookingManagement.bean;

public class CutomerInfoBean {
	private String userID;
	private String userName;
	private String customerMailID;
	private String customerPassword;
	private int customerAge;
	private long customerMobileNumber;
	private String customeraddress;

	public String getuserID() {
		return userID;
	}

	public void setuserID(String id) {
		this.userID = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCustomerMailID() {
		return customerMailID;
	}

	public void setCustomerMailID(String customerMailID) {
		this.customerMailID = customerMailID;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public int getCustomerAge() {
		return customerAge;
	}

	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}

	public long getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(long customerMobileNumber) {
		this.customerMobileNumber = customerMobileNumber;
	}

	public String getCustomeraddress() {
		return customeraddress;
	}

	public void setCustomeraddress(String customeraddress) {
		this.customeraddress = customeraddress;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CutomerInfoBean other = (CutomerInfoBean) obj;
		if (customerAge != other.customerAge)
			return false;
		if (customerMailID == null) {
			if (other.customerMailID != null)
				return false;
		} else if (!customerMailID.equals(other.customerMailID))
			return false;
		if (customerMobileNumber != other.customerMobileNumber)
			return false;
		if (customerPassword == null) {
			if (other.customerPassword != null)
				return false;
		} else if (!customerPassword.equals(other.customerPassword))
			return false;
		if (customeraddress == null) {
			if (other.customeraddress != null)
				return false;
		} else if (!customeraddress.equals(other.customeraddress))
			return false;
		if (userID == null) {
			if (other.userID != null)
				return false;
		} else if (!userID.equals(other.userID))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}

	public String toString() {
		return "ID  = " + userID + "   UserName = " + userName + "   mailID = " + customerMailID + "   passsword = "
				+ customerPassword + "   Age = " + customerAge + "   mobile = " + customerMobileNumber + "   address = "
				+ customeraddress + "\n";
	}

}
