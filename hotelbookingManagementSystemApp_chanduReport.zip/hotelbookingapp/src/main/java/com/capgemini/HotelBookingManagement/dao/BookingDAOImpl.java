package com.capgemini.HotelBookingManagement.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.BookingInfoBean;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;
import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.exceptions.BookingDetailsNotFoundException;
import com.capgemini.HotelBookingManagement.exceptions.DetailsNotFoundException;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class BookingDAOImpl implements BookingDAO {
	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner scan = new Scanner(System.in);

	static List<BookingInfoBean> bookingList = new ArrayList<BookingInfoBean>();
	CustomerDAO customerdao = HotelBookingFactory.getCustomerImplInstance();
	static {

		BookingInfoBean booking1 = HotelBookingFactory.getBookingInfoBeanInstance();
		booking1.setBookingID(145124458);
		booking1.setCustID(2020);
		booking1.setCustName("Naveen");
		booking1.setPhoneNor(9875451245l);
		booking1.setPrice(10000);
		booking1.setHotelName("Taj Hotel");
		booking1.setRoomNum(121);
		booking1.setInDate(LocalDate.of(2020, 01, 01));
		booking1.setOutdate(LocalDate.of(2020, 01, 02));
		booking1.setIntime("12:00 PM");
		booking1.setOutTime("11:00 AM");
		booking1.setHotelLocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");
		booking1.setRoomsBooked(1);
		booking1.setRoomType("Classic-Room");

		BookingInfoBean booking2 = HotelBookingFactory.getBookingInfoBeanInstance();
		booking2.setBookingID(15121245);
		booking2.setCustID(2021);
		booking2.setCustName("Srinu");
		booking2.setPhoneNor(9875451245l);
		booking2.setPrice(15000);
		booking2.setHotelName("Taj Hotel");
		booking2.setRoomNum(125);
		booking2.setInDate(LocalDate.of(2020, 01, 02));
		booking2.setOutdate(LocalDate.of(2020, 01, 03));
		booking2.setIntime("12:00 PM");
		booking2.setOutTime("11:00 AM");
		booking2.setHotelLocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");
		booking2.setRoomsBooked(1);
		booking2.setRoomType("Duplex-Room");

		BookingInfoBean booking3 = HotelBookingFactory.getBookingInfoBeanInstance();

		booking3.setBookingID(187845441);
		booking3.setCustID(2022);
		booking3.setCustName("Srinivas");
		booking3.setPhoneNor(9875451245l);
		booking3.setPrice(7000);
		booking3.setHotelName("Hotel Vivantha");
		booking3.setRoomNum(1221);
		booking3.setInDate(LocalDate.of(2020, 01, 01));
		booking3.setOutdate(LocalDate.of(2020, 01, 02));
		booking3.setIntime("12:00 PM");
		booking3.setOutTime("11:00 AM");
		booking3.setRoomsBooked(1);
		booking3.setRoomType("Classic-Room");
		booking3.setHotelLocation("1-22/25 Vishwa-Bhavan, Madhapur, Hyderabad");

		BookingInfoBean booking4 = HotelBookingFactory.getBookingInfoBeanInstance();
		booking4.setBookingID(145124458);
		booking4.setCustID(2023);
		booking4.setCustName("sunny");
		booking4.setPhoneNor(9875451245l);
		booking4.setPrice(11000);
		booking4.setHotelName("Maroit Hotel");
		booking4.setRoomNum(111);
		booking4.setInDate(LocalDate.of(2020, 01, 01));
		booking4.setOutdate(LocalDate.of(2020, 01, 02));
		booking4.setIntime("12:00 PM");
		booking4.setOutTime("11:00 AM");
		booking4.setRoomsBooked(1);
		booking4.setRoomType("Classic-Room");
		booking4.setHotelLocation("15/211-12 Kanchana Bavan, Anandarao Circle, Bangalore");

		BookingInfoBean booking5 = HotelBookingFactory.getBookingInfoBeanInstance();
		booking5.setBookingID(145124458);
		booking5.setCustID(2024);
		booking5.setCustName("chandu");
		booking5.setPhoneNor(9875412141l);
		booking5.setPrice(13000);
		booking5.setHotelName("The Hotel VPark");
		booking5.setRoomNum(202);
		booking5.setInDate(LocalDate.of(2020, 01, 01));
		booking5.setOutdate(LocalDate.of(2020, 01, 02));
		booking5.setIntime("12:00 PM");
		booking5.setOutTime("11:00 AM");
		booking5.setRoomsBooked(1);
		booking4.setRoomType("Duplex-Room");
		booking5.setHotelLocation("12-22/123 Mithra-Building,Basavan gudi, bangalore");

		bookingList.add(booking1);
		bookingList.add(booking2);
		bookingList.add(booking3);
		bookingList.add(booking4);
		bookingList.add(booking5);

	}

	public RoomInfoBean insertBooking(RoomInfoBean roominfobean, int rooms) {
		BookingInfoBean bookinginfobean = HotelBookingFactory.getBookingInfoBeanInstance();

		logger.info("Your selected room Type : " + roominfobean.getRoomType());
		logger.info("Number of rooms selected : " + rooms);
		logger.info("Room price is           : " + roominfobean.getRoomPrice() * rooms + "/-");

		logger.info("Enter book check-in date (FORMAT:YYYY-MM-DD)");
		String inDate = scan.nextLine();
		while (!inputvalidation.dateValidation(inDate)) {
			logger.info("please enter valid date format should be [YYYY-MM-DD]");
			inDate = scan.nextLine();

		}
		LocalDate checkinDate = LocalDate.parse(inDate);

		while (checkinDate.isBefore(LocalDate.now())) {
			logger.info("Check-in date should be present date or future date");
			inDate = scan.nextLine();
			while (!inputvalidation.dateValidation(inDate)) {
				logger.info("Enter valid date");
			}
			checkinDate = LocalDate.parse(inDate);

		}

		logger.info("Enter book check-out date (FORMAT:YYYY-MM-DD)");
		String outDate = scan.nextLine();
		while (!inputvalidation.dateValidation(outDate)) {
			logger.info("please enter valid date format should be [yyyy-mm-dd]");
			outDate = scan.nextLine();
		}

		LocalDate checkoutDate = LocalDate.parse(outDate);
		while (checkoutDate.isBefore(checkinDate)) {
			logger.info("Check-out date should be check-in or future date");
			outDate = scan.nextLine();
			while (!inputvalidation.dateValidation(outDate)) {
				logger.info("Enter valid date format should be [yyyy-mm-dd]");
			}
			checkoutDate = LocalDate.parse(outDate);
		}

		int indates = checkinDate.getDayOfMonth();
		int outdates = checkoutDate.getDayOfMonth();
		int diff = outdates - indates;

		bookinginfobean.setInDate(checkinDate);
		bookinginfobean.setOutdate(checkoutDate);

		logger.info("proceed to Booking Enter userID");
		String userid = scan.nextLine();
		while (!inputvalidation.idValidation(userid)) {
			logger.info("please enter valid id format should be [4-5 digits]");
			userid = scan.nextLine();
		}

		CustomerDAO customerdao = HotelBookingFactory.getCustomerImplInstance();
		boolean value = customerdao.getCustomerIDForBooking(userid);
		while (value == false) {
			logger.info("please enter valid id format should be [4 digits]");
			userid = scan.nextLine();
			value = customerdao.getCustomerIDForBooking(userid);
		}

		logger.info("Enter name");
		String name = scan.nextLine();
		while (!inputvalidation.userNameValidation(name)) {
			logger.info("please enter valid username format should be [First name 4-15 characters] ");
			name = scan.nextLine();
		}

		logger.info("Enter your mobile number ");
		String mNumber = scan.nextLine();
		while (!inputvalidation.contactValidation(mNumber)) {
			logger.info("please enter valid mobile number  [10-digits]");
			mNumber = scan.nextLine();
		}

		int userId = Integer.parseInt(userid);
		bookinginfobean.setBookingID(bookinginfobean.hashCode());
		bookinginfobean.setCustID(userId);
		bookinginfobean.setCustName(name);
		long num = Long.parseLong(mNumber);
		bookinginfobean.setPhoneNor(num);
		bookinginfobean.setHotelName(roominfobean.getRoomType());
		bookinginfobean.setPrice(roominfobean.getRoomPrice() * rooms);
		bookinginfobean.setHotelName(roominfobean.getRoomSpecifiedHotel());
		bookinginfobean.setRoomNum(roominfobean.getRoomNo());
		bookinginfobean.setRoomsBooked(rooms);
		bookinginfobean.setIntime("12:00 PM");
		bookinginfobean.setOutTime("11:00 AM");
		bookinginfobean.setInDate(checkinDate);
		bookinginfobean.setOutdate(checkoutDate);
		bookinginfobean.setRoomType(roominfobean.getRoomType());
		bookinginfobean.setHotelLocation(roominfobean.getSpecifiedHotellocation());

		int bill1 = roominfobean.getRoomPrice() * rooms;
		if (diff == 0) {
			bill1 = roominfobean.getRoomPrice() * rooms;
		} else {
			bill1 = bill1 * diff;
		}

		int size = bookingList.size();
		bookingList.add(bookinginfobean);
		if (size == bookingList.size()) {

			logger.info("Booking Fail");

		} else {

			logger.info("Total Bill :  " + bill1 + "/-");
			logger.info("Go to payments Enter [yes] ");
			String choice2 = scan.nextLine();
			while (!choice2.equals("yes")) {
				logger.info("Invalid choice please Re-Enter [yes]");
				choice2 = scan.nextLine();
			}

			PaymentDAOImpl payment = HotelBookingFactory.getPaymentDAOImplInstance();
			payment.getPayments(bill1, bookinginfobean.hashCode());

			logger.info("========================================");
			logger.info("Booking Successful");
			logger.info("Your booking details :  " + "\n" + bookinginfobean.toString1());
			logger.info("========================================");
			for (int i = 1; i <= rooms; i++) {
				RoomDAO roomdao = HotelBookingFactory.getRoomDAOImplInstance();
				roomdao.setRoomUpdate(roominfobean.getRoomNo() + i);
			}
		}
		customerdao.startBooking();
		return roominfobean;

	}

	public boolean getGuestListSpecifiedHotel(String hotelname) {
		int counts = 0;
		logger.info("========================================");
		for (BookingInfoBean bookinginfobean : bookingList) {
			if (bookinginfobean.getHotelName().equals(hotelname)) {
				logger.info(bookinginfobean);
				counts++;
			}

		}
		try {
			if (counts == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				logger.info("========================================");
				return true;
			}
		} catch (BookingDetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

	public boolean getBookingSpecifiedDate() {

		logger.info("Enter date to check bookings [yyyy-mm-dd]");
		String date = scan.nextLine();
		while (!inputvalidation.dateValidation(date)) {
			logger.info("please enter valid date farmat should be [yyyy-mm-dd]");
			date = scan.nextLine();
		}
		LocalDate dates = LocalDate.parse(date);
		logger.info("========================================");
		int counts = 0;
		for (BookingInfoBean bookinginfobean : bookingList) {

			if (bookinginfobean.getInDate().equals(dates)) {
				logger.info(bookinginfobean);
				counts++;
			}

		}
		try {
			if (counts == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				logger.info("========================================");
				return true;
			}
		} catch (BookingDetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

	public List<BookingInfoBean> getAllBookingsDetails() {
		int counts = 0;

		logger.info("========================================");
		for (BookingInfoBean bookinginfobean : bookingList) {
			logger.info(bookinginfobean);
			counts++;
		}
		try {
			if (counts == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				logger.info("========================================");
			}
		} catch (BookingDetailsNotFoundException e) {
			System.err.println(e.getMessage());
		}
		return bookingList;
	}

	public boolean getBookingDetailsforCustomer() {
		int count = 0;
		logger.info("Enter user Id to get booking details");
		String idUser = scan.nextLine();
		while (!inputvalidation.idValidation(idUser)) {
			logger.info("please enter valid id format should be [4-5] digits]");
			idUser = scan.nextLine();
		}
		int cusID = Integer.parseInt(idUser);
		logger.info("========================================");
		for (BookingInfoBean bookinginfobean : bookingList) {

			if (bookinginfobean.getCustID() == (cusID)) {
				logger.info(bookinginfobean.toString1());
				count++;
			}

		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				logger.info("========================================");
				return true;

			}
		} catch (BookingDetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

	public boolean getBookingSpecifiedHotel(String hotelName) {
		int count = 0;
		logger.info("========================================");
		for (BookingInfoBean bookinginfobean : bookingList) {

			if (bookinginfobean.getHotelName().equals(hotelName)) {
				logger.info(bookinginfobean);
				count++;
			}

		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				logger.info("========================================");
				return true;
			}
		} catch (BookingDetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

	public boolean getBookingDetailsByEmployee() {
		int count = 0;
		logger.info("Enter user Id to get booking details");
		String idUser = scan.nextLine();
		while (!inputvalidation.idValidation(idUser)) {
			logger.info("please enter valid id format should be [4-5 digits]");
			idUser = scan.nextLine();
		}
		int cusID = Integer.parseInt(idUser);
		logger.info("========================================");
		for (BookingInfoBean bookinginfobean : bookingList) {

			if (bookinginfobean.getCustID() == (cusID)) {
				logger.info(bookinginfobean.toString());
				count++;
			}

		}
		try {
			if (count == 0) {
				throw new BookingDetailsNotFoundException();
			} else {
				logger.info("========================================");
				return true;
			}
		} catch (BookingDetailsNotFoundException e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

}
