package com.capgemini.HotelBookingManagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;
import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;
import com.capgemini.HotelBookingManagement.exceptions.DetailsNotFoundException;
import com.capgemini.HotelBookingManagement.exceptions.HotelsDetailsNotFoundException;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class HotelDAOImpl implements HotelDAO {

	static List<HotelInfoBean> hotelList = new ArrayList<HotelInfoBean>();
	static final Logger logger = Logger.getLogger(HotelDAOImpl.class);
	Scanner scan = new Scanner(System.in);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();

	static {
		HotelInfoBean hotelinfobean1 = HotelBookingFactory.getHotelInfoBeanInstance();
		hotelinfobean1.setHotelnumber(1);
		hotelinfobean1.setHotelName("Taj Hotel");
		hotelinfobean1.setLocation("Hyderabad");
		hotelinfobean1.setHotelMail("hoteltaj@123.gmail.com");
		hotelinfobean1.setHotelMobile(8945687547l);
		hotelinfobean1.setHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");
		hotelinfobean1.setHotelDescription("\nDescription : \nSpecial Features\nThe hotel offers clean,"
				+ "ventilted rooms with neat furniture.\nThe property has a kitchen,"
				+ "an elegantly furnished dining \narea and banquent hall for events and swimming pool"
				+ "\n\nAmenties \nEvery room has TV, AC, and free WIFI. Guests are also provided \nwith parking facility,"
				+ "power backup,CCTV security, \n Gym facility and card payment facilities. \n");

		HotelInfoBean hotelinfobean2 = HotelBookingFactory.getHotelInfoBeanInstance();
		hotelinfobean2.setHotelnumber(2);
		hotelinfobean2.setHotelName("Hotel Vivantha");
		hotelinfobean2.setLocation("Hyderabad");
		hotelinfobean2.setHotelMail("hoteltaj@123.gmail.com");
		hotelinfobean2.setHotelMobile(8454545454l);
		hotelinfobean2.setHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");
		hotelinfobean2.setHotelDescription("\nDescription : \nSpecial Features\nThe hotel offers clean,"
				+ "ventilted rooms with neat furniture.\nThe property has a kitchen,"
				+ "an elegantly furnished dining \narea and banquent hall for events"
				+ "\n\nAmenties \nEvery room has TV, AC, and free WIFI. Guests are also provided \nwith parking facility,"
				+ "power backup,CCTV security, and \ncard payment facilities. \n");

		HotelInfoBean hotelinfobean3 = HotelBookingFactory.getHotelInfoBeanInstance();
		hotelinfobean3.setHotelnumber(1);
		hotelinfobean3.setHotelName("Maroit Hotel");
		hotelinfobean3.setLocation("Bangalore");
		hotelinfobean3.setHotelMail("MariotBooking@098.gmail.com");
		hotelinfobean3.setHotelMobile(8121245154l);
		hotelinfobean3.setHotellocation("15/211-12 Kanchana Bavan, Anandarao Circle, Bangalore");
		hotelinfobean3.setHotelDescription("\nDescription : \nSpecial Features\nThe hotel offers clean,"
				+ "ventilted rooms with neat furniture.\nThe property has a kitchen,"
				+ "an elegantly furnished dining \narea and banquent hall for events and Swimming pool"
				+ "\n\nAmenties \nEvery room has TV, AC, and free WIFI. Guests are also provided \nwith parking facility,"
				+ "power backup,CCTV security, \nGym facility and card payment facilities. \n");

		HotelInfoBean hotelinfobean4 = HotelBookingFactory.getHotelInfoBeanInstance();
		hotelinfobean4.setHotelnumber(2);
		hotelinfobean4.setHotelName("The Hotel Vpark");
		hotelinfobean4.setLocation("Bangalore");
		hotelinfobean4.setHotelMail("hotelark@123.gmail.com");
		hotelinfobean4.setHotelMobile(7878545454l);
		hotelinfobean4.setHotellocation("12-22/123 Mithra-Building,Basavan gudi, bangalore");
		hotelinfobean4.setHotelDescription("\nDescription : \nSpecial Features\nThe hotel offers clean,"
				+ "ventilted rooms with neat furniture.\nThe property has a kitchen,"
				+ "an elegantly furnished dining \narea and banquent hall for events"
				+ "\n\nAmenties \nEvery room has TV, AC, and free WIFI. Guests are also provided \nwith parking facility,"
				+ "power backup,CCTV security, and \ncard payment facilities. \n");

		hotelList.add(hotelinfobean1);
		hotelList.add(hotelinfobean2);

		hotelList.add(hotelinfobean3);
		hotelList.add(hotelinfobean4);

	}

	public HotelInfoBean getHotel(int num) {

		BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();

		N: do {
			int count = 1;
			int check = 0;
			logger.info("========================================");
			for (HotelInfoBean hotelinfobean : hotelList) {
				logger.info(count + "." + hotelinfobean.getHotelName());
				count++;
			}

			if (num > 1) {

				logger.info("Continue Enter 1 or Back Enter [2-3]");
				String cc = scan.nextLine();
				while (!inputvalidation.selectinValidation(cc)) {
					logger.info("please enter valid choice");
					cc = scan.nextLine();
				}
				int optionsel = Integer.parseInt(cc);
				if (optionsel == 1) {
					logger.info("Enter Hotel you Required");
					String hotels = scan.nextLine();
					while (!inputvalidation.fullNameValidate(hotels)) {
						logger.info("please enter valid name format like [first name] ");
						hotels = scan.nextLine();
					}
					for (HotelInfoBean hotel : hotelList) {
						if (hotel.getHotelName().equals(hotels)) {
							logger.info("Hotel is Found");
							bookingdao.getBookingSpecifiedHotel(hotels);
							check++;

						}
					}
				} else {
					break N;
				}
				try {
					if (check == 0) {
						throw new HotelsDetailsNotFoundException("Hotel Detail not Found");
					} else {
						logger.info("=========================================");
					}
				} catch (HotelsDetailsNotFoundException e) {
					System.err.println(e.Getmessages());
					count = 0;
				}
			}
			break N;
		} while (true);

		return null;

	}

	public boolean getListForSpecifiedHotelGuest() {

		BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();

		N: do {
			int count = 1;
			int check = 1;
			for (HotelInfoBean hotelinfobean : hotelList) {
				logger.info(count + "." + hotelinfobean.getHotelName());
				count++;
			}

			logger.info("Continue Enter 1 or Back Enter [2-3]");
			String cc = scan.nextLine();
			while (!inputvalidation.selectinValidation(cc)) {
				logger.info("please enter valid choice ");
				cc = scan.nextLine();
			}
			int optionsel = Integer.parseInt(cc);
			if (optionsel == 1) {
				logger.info("Enter Hotel you Required");
				String hotels = scan.nextLine();
				while (!inputvalidation.fullNameValidate(hotels)) {
					logger.info("please enter valid name format is [first name] ");
					hotels = scan.nextLine();
				}
				for (HotelInfoBean hotel : hotelList) {
					if (hotel.getHotelName().equals(hotels)) {
						logger.info("Hotel is Found");
						bookingdao.getBookingSpecifiedHotel(hotels);
						check++;

					}
				}
			} else {
				break N;
			}
			try {
				if (check == 0) {
					throw new HotelsDetailsNotFoundException("No Guest Details Present in this Hotel");
				} else {
					logger.info("=========================================");
					return true;
				}
			} catch (HotelsDetailsNotFoundException e) {
				System.err.println(e.Getmessages());
				count = 0;
				return false;
			}
		} while (true);
		return true;

	}

	public boolean addHotel(HotelInfoBean hotel) {

		String location1 = "Hyderabad";
		String location2 = "Bangalore";

		logger.info("Enter details to add hotel");

		logger.info("Please enter Hotel Location");
		String addLocation = scan.nextLine();
		while (!inputvalidation.nameValidation(addLocation)) {
			logger.info("Please enter valid location like [Hyderabad 'or' Bangalore]");
			addLocation = scan.nextLine();
		}

		while (!(location1.equals(addLocation) || location2.equals(addLocation))) {
			logger.info("please enter valid location as [Hyderabad 'or' Bangalore]");
			addLocation = scan.nextLine();

			while (!inputvalidation.nameValidation(addLocation)) {
				logger.info("Please enter valid location like [Hyderabad 'or' Bangalore]");
				addLocation = scan.nextLine();
			}

		}

		logger.info("Please Enter Hotel Name");
		String addHotelname = scan.nextLine();
		while (!inputvalidation.fullNameValidate(addHotelname)) {
			logger.info("Please enter valid name like [Hotel Park]");
			addHotelname = scan.nextLine();
		}

		for (HotelInfoBean hotelinfobean1 : hotelList) {
			while (hotelinfobean1.getHotelName().equals(addHotelname)) {
				logger.info("This user MAIL Already used Try Different mail");
				addHotelname = scan.nextLine();
				while (!inputvalidation.fullNameValidate(addHotelname)) {
					logger.info("please enter valid Name format should be [Hotel Park]");
					addHotelname = scan.nextLine();
				}

			}
		}

		logger.info("Please enter hotel number");
		String hotelnum = scan.nextLine();
		while (!inputvalidation.rmNumberValidate(hotelnum)) {
			logger.info("Please enter valid number like [1-2 digits]");
			hotelnum = scan.nextLine();
		}
		int hotelnumber = Integer.parseInt(hotelnum);

		for (HotelInfoBean hotelinfobean1 : hotelList) {
			while (hotelinfobean1.getHotelnumber() == hotelnumber) {
				logger.info("This Hotel number Already Exist Try Different");
				hotelnum = scan.nextLine();
				hotelnumber = Integer.parseInt(hotelnum);
				while (!inputvalidation.hotelCodeValidate(hotelnum)) {
					logger.info("please enter valid format should be [1-2 digits]");
					hotelnum = scan.nextLine();
				}
				hotelnumber = Integer.parseInt(hotelnum);
			}

		}
		logger.info("Please enter mailid");
		String mail = scan.nextLine();
		while (!inputvalidation.emailValidation(mail)) {
			logger.info("Please enter valid mailid should be [abcd@11gmail.com]");
			mail = scan.nextLine();
		}
		for (HotelInfoBean hotelinfobean1 : hotelList) {
			while (hotelinfobean1.getHotelMail().equals(mail)) {
				logger.info("This user MAIL Already used Try Different mail");
				mail = scan.nextLine();

				while (!inputvalidation.emailValidation(mail)) {
					logger.info("please enter valid Name farmat should be [abcd@gmail.com]");
					mail = scan.nextLine();
				}
			}

		}

		logger.info("Please enter Phone number");
		String number = scan.nextLine();
		while (!inputvalidation.contactValidation(number)) {
			logger.info("Please enter valid phone number [10-digits]");
			number = scan.nextLine();
		}
		long phonenumber = Long.parseLong(number);

		logger.info("Please enter hotel description");
		String hotelDesc = scan.nextLine();
		while (!inputvalidation.discValidate(hotelDesc)) {
			logger.info("Please enter valid phone number [10-digits]");
			hotelDesc = scan.nextLine();
		}

		hotel.setHotelnumber(hotelnumber);
		hotel.setHotelName(addHotelname);
		hotel.setLocation(addLocation);
		hotel.setHotelMail(mail);
		hotel.setHotelMobile(phonenumber);
		hotel.setHotelDescription(hotelDesc);

		int size = hotelList.size();
		hotelList.add(hotel);

		if (size == hotelList.size()) {
			logger.info("Hotel details not added");
		} else {
			logger.info("Hotel details added successful");

		}

		return true;
	}

	public boolean updateHotel(HotelInfoBean hotel) {
		int count = 0;
		String location1 = "Hyderabad";
		String location2 = "Bangalore";

		logger.info("Enter details to update hotel");

		logger.info("Please enter Hotel Location");
		String locations = scan.nextLine();
		while (!(location1.equals(locations) || location2.equals(locations))) {
			logger.info("please enter location like  [Hyderabad' or'Bangalore]");
			locations = scan.nextLine();

			while (!inputvalidation.nameValidation(locations)) {
				logger.info("Please enter valid location like [Hyderabad' or'Bangalore]");
				locations = scan.nextLine();
			}
		}

		logger.info("Please enter hotel number");
		String hotelnum = scan.nextLine();
		while (!inputvalidation.rmNumberValidate(hotelnum)) {
			logger.info("Please enter valid number like [1-2 digits]");
			hotelnum = scan.nextLine();
		}
		int hotelnumber = Integer.parseInt(hotelnum);

		logger.info("Please Enter Hotel Name");
		String hotelname = scan.nextLine();
		while (!inputvalidation.fullNameValidate(hotelname)) {
			logger.info("Please enter valid name like [Hotel Vivantha]");
			hotelname = scan.nextLine();
		}

		for (HotelInfoBean hotelinfo : hotelList) {
			if (hotelinfo.getHotelnumber() == hotelnumber && hotelinfo.getHotelName().equals(hotelname)) {
				count++;
				logger.info("Request is Done ");
				logger.info("update details");

				logger.info("Please enter hotel number");
				String hotelnumm = scan.nextLine();
				while (!inputvalidation.hotelCodeValidate(hotelnumm)) {
					logger.info("Please enter number like [3]");
					hotelnumm = scan.nextLine();
				}
				int hoteln = 0;
				hoteln = Integer.parseInt(hotelnumm);

				int hotelnumberr = Integer.parseInt(hotelnumm);

				logger.info("Please Enter Hotel Name");
				String setHotelName = scan.nextLine();
				while (!inputvalidation.fullNameValidate(setHotelName)) {
					logger.info("Please enter valid name like [Hotel Vivanta]");
					setHotelName = scan.nextLine();
				}

				logger.info("Please enter mailid");
				String mails = scan.nextLine();
				while (!inputvalidation.emailValidation(mails)) {
					logger.info("Please enter valid mailid format should be [abcd@gmail.com]");
					mails = scan.nextLine();
				}
				for (HotelInfoBean hotelinfobean1 : hotelList) {
					while (hotelinfobean1.getHotelMail().equals(mails)) {
						logger.info("This user MAIL Already used Try Different mail");
						mails = scan.nextLine();

						while (!inputvalidation.emailValidation(mails)) {
							logger.info("please enter valid Name format should be [abcd@gmail.com]");
							mails = scan.nextLine();
						}
					}

				}

				logger.info("Please enter Phone number");
				String numbers = scan.nextLine();
				while (!inputvalidation.contactValidation(numbers)) {
					logger.info("Please enter valid phone number");
					numbers = scan.nextLine();
				}
				long phonenumberss = Long.parseLong(numbers);

				logger.info("Please enter hotel description");
				String hotelDesc1 = scan.nextLine();
				while (!inputvalidation.discValidate(hotelDesc1)) {
					logger.info("Please enter valid phone number");
					hotelDesc1 = scan.nextLine();
				}

				hotelinfo.setHotelnumber(hotelnumberr);
				hotelinfo.setHotelName(setHotelName);
				hotelinfo.setLocation(locations);
				hotelinfo.setHotelMail(mails);
				hotelinfo.setHotelMobile(phonenumberss);
				hotelinfo.setHotelDescription(hotelDesc1);

			}
		}

		try {
			if (count == 0) {
				throw new DetailsNotFoundException();
			} else {
				logger.info("data updated successfully");
			}
		} catch (DetailsNotFoundException e) {
			System.err.println(e.getMessage());
		}
		return true;
	}

	public boolean deleteHotel() {
		logger.info("Please enter hotel number to delete");
		String deletehotelnum = scan.nextLine();
		while (!inputvalidation.rmNumberValidate(deletehotelnum)) {
			logger.info("Please enter valid number like [1-5 digits]");
			deletehotelnum = scan.nextLine();
		}

		logger.info("Please enter Hotel name");
		String deletehotelname = scan.nextLine();
		while (!inputvalidation.fullNameValidate(deletehotelname)) {
			logger.info("Please enter valid name like [Hotel Polasa]");
			deletehotelname = scan.nextLine();
		}
		int check = 0;
		int hotelnumber = Integer.parseInt(deletehotelnum);
		Iterator<HotelInfoBean> hotelbean = hotelList.iterator();

		while (hotelbean.hasNext()) {
			HotelInfoBean str = hotelbean.next();
			if (str.getHotelnumber() == hotelnumber && str.getHotelName().equals(deletehotelname)) {
				check++;
				logger.info("Hotel found");
				hotelbean.remove();
			}
		}
		try {
			if (check == 0) {
				throw new HotelsDetailsNotFoundException("NO DATA FOUND TO DELETE");

			} else {
				logger.info("Hotel Deleted sucessfull");
			}
		} catch (HotelsDetailsNotFoundException d) {
			System.err.println(d.Getmessages());
		}
		return true;
	}

	public boolean getHotelDetails() {
		int check = 0;
		logger.info("Enter hotel Name");
		String hotelName = scan.nextLine();
		while (!inputvalidation.fullNameValidate(hotelName)) {
			logger.info("Please enter valid name like [Hotel Swetha]");
			hotelName = scan.nextLine();
		}

		logger.info("=========================================");
		for (HotelInfoBean hotelinfobean : hotelList) {
			if (hotelinfobean.getHotelName().equals(hotelName)) {
				logger.info(hotelinfobean);
				check++;
			}
		}

		try {
			if (check == 0) {
				throw new HotelsDetailsNotFoundException("NO DETAILS FOUND");
			} else {
				logger.info("=========================================");
			}
		} catch (HotelsDetailsNotFoundException e) {
			System.err.println(e.Getmessages());
		}
		return true;

	}

	public boolean getAllHotelsDetails() {
		int check = 0;
		logger.info("=========================================");
		for (HotelInfoBean hotelinfobean : hotelList) {
			logger.info(hotelinfobean);
			check++;
		}
		try {
			if (check == 0) {
				throw new HotelsDetailsNotFoundException("HOTEL DETAILS NOT FOUND");
			} else {
				logger.info("=========================================");
			}
		} catch (HotelsDetailsNotFoundException e) {
			System.err.println(e.Getmessages());
		}
		return true;

	}

	public boolean getHotels(String location) {

		RoomDAO roomdaoimpl = HotelBookingFactory.getRoomDAOImplInstance();
		C: do {
			int count = 0;
			int check = 1;
			for (HotelInfoBean hotelinfobean : hotelList) {
				if (hotelinfobean.getLocation().equals(location)) {
					logger.info(check + "." + hotelinfobean.getHotelName());
					logger.info(hotelinfobean.getHotelDescription());
					check++;
				}
			}

			logger.info("Proceed Enter 1 or Back Enter 2-3");
			String cc = scan.nextLine();
			while (!inputvalidation.selectinValidation(cc)) {
				logger.info("please enter valid choice  ");
				cc = scan.nextLine();
			}
			int optionsel = Integer.parseInt(cc);
			if (optionsel == 1) {
				logger.info("Enter Hotel Name you Required");
				String hotels = scan.nextLine();
				while (!inputvalidation.fullNameValidate(hotels)) {
					logger.info("please enter valid name as [Taj Hotel] ");
					hotels = scan.nextLine();
				}
				for (HotelInfoBean hotel : hotelList) {
					if (hotel.getHotelName().equals(hotels)) {
						logger.info("Hotel is Found");
						count++;

					}
				}
				try {
					if (count == 1) {
						boolean val1 = roomdaoimpl.roomsCheckingAvailability(hotels);
						if (val1 == true) {
							roomdaoimpl.roomSelection(hotels);
							break C;
						} else {
							break C;
						}
					} else {
						throw new HotelsDetailsNotFoundException("HOTEL NOT FOUND");
					}
				} catch (HotelsDetailsNotFoundException e) {
					System.err.println(e.Getmessages());
					count = 0;
				}

			} else {
				break C;
			}

		} while (true);

		return true;
	}
}
