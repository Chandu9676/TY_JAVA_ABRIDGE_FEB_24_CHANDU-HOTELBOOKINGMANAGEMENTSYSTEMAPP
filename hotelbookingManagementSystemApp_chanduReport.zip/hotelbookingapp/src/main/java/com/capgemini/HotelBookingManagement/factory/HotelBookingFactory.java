package com.capgemini.HotelBookingManagement.factory;

import com.capgemini.HotelBookingManagement.bean.AdminInfoBean;
import com.capgemini.HotelBookingManagement.bean.BookingInfoBean;
import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;
import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;
import com.capgemini.HotelBookingManagement.bean.PaymentInfoBean;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;
import com.capgemini.HotelBookingManagement.dao.AdminDAO;
import com.capgemini.HotelBookingManagement.dao.AdminDAOImpl;
import com.capgemini.HotelBookingManagement.dao.BookingDAO;
import com.capgemini.HotelBookingManagement.dao.BookingDAOImpl;
import com.capgemini.HotelBookingManagement.dao.CustomerDAO;
import com.capgemini.HotelBookingManagement.dao.CustomerDAOImpl;
import com.capgemini.HotelBookingManagement.dao.EmployeeManagementDAO;
import com.capgemini.HotelBookingManagement.dao.EmployeeManagementDAOImpl;
import com.capgemini.HotelBookingManagement.dao.HotelDAO;
import com.capgemini.HotelBookingManagement.dao.HotelDAOImpl;
import com.capgemini.HotelBookingManagement.dao.PaymentDAOImpl;
import com.capgemini.HotelBookingManagement.dao.RoomDAO;
import com.capgemini.HotelBookingManagement.dao.RoomDAOImpl;
import com.capgemini.HotelBookingManagement.service.Admin;
import com.capgemini.HotelBookingManagement.service.AdminImpl;
import com.capgemini.HotelBookingManagement.service.EmployeeManagement;
import com.capgemini.HotelBookingManagement.service.EmployeeManagementImpl;
import com.capgemini.HotelBookingManagement.service.ServiceCustomer;
import com.capgemini.HotelBookingManagement.service.ServiceCustomerImpl;
import com.capgemini.HotelBookingManagement.validation.InputValidationImpl;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class HotelBookingFactory {

	public static CutomerInfoBean getCustomerInfoInstance() {
		CutomerInfoBean customerinfobean = new CutomerInfoBean();
		return customerinfobean;
	}

	public static ServiceCustomer getServiceInstance() {
		ServiceCustomerImpl service = new ServiceCustomerImpl();
		return service;
	}

	public static CustomerDAO getCustomerImplInstance() {
		return new CustomerDAOImpl();
	}

	public static EmployeeManagementDAO getEmployeeDAOImplInstance() {
		return new EmployeeManagementDAOImpl();
	}

	public static EmployeeManagement getEmployeeImplInstance() {
		return new EmployeeManagementImpl();
	}

	public static EmployeeInfoBean getEmployeeInfoBeanInstance() {
		return new EmployeeInfoBean();
	}

	public static HotelInfoBean getHotelInfoBeanInstance() {
		return new HotelInfoBean();
	}

	public static HotelDAO getHotelDAOImplInstance() {
		return new HotelDAOImpl();
	}

	public static RoomInfoBean getRoomInfoBeanInstance() {
		return new RoomInfoBean();
	}

	public static BookingDAO getBookingDAOImplInstance() {
		BookingDAO bookingdao = new BookingDAOImpl();
		return bookingdao;
	}

	public static BookingInfoBean getBookingInfoBeanInstance() {
		return new BookingInfoBean();
	}

	public static RoomDAO getRoomDAOImplInstance() {
		RoomDAO roomdao = new RoomDAOImpl();
		return roomdao;
	}

	public static AdminDAO getAdminDAOImplInstance() {
		AdminDAO admindao = new AdminDAOImpl();
		return admindao;
	}

	public static Admin getAdminImplInstance() {
		Admin admin = new AdminImpl();
		return admin;
	}

	public static AdminInfoBean getAdminInfoBeanInstance() {
		AdminInfoBean admininfobean = new AdminInfoBean();
		return admininfobean;
	}

	public static PaymentInfoBean getPaymentInfoBeanInstance() {
		return new PaymentInfoBean();
	}

	public static PaymentDAOImpl getPaymentDAOImplInstance() {
		return new PaymentDAOImpl();
	}

	public static InputValidations getInputValidationInstance() {
		InputValidations inputValidations = new InputValidationImpl();
		return inputValidations;
	}
}
