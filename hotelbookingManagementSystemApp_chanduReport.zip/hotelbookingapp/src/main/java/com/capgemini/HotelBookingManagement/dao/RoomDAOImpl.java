package com.capgemini.HotelBookingManagement.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;
import com.capgemini.HotelBookingManagement.exceptions.HotelsDetailsNotFoundException;
import com.capgemini.HotelBookingManagement.exceptions.RoomDetailsNotFoundException;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class RoomDAOImpl implements RoomDAO {

	static final Logger logger = Logger.getLogger(RoomDAOImpl.class);
	static List<RoomInfoBean> roomsList = new ArrayList<RoomInfoBean>();
	Scanner sc = new Scanner(System.in);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();

	static {

		RoomInfoBean room1 = HotelBookingFactory.getRoomInfoBeanInstance();
		room1.setRoomNo(121);
		room1.setRoomType("Classic-Room");
		room1.setRoomPrice(10000);
		room1.setHotelCode(1);
		room1.setRoomSpecifiedHotel("Taj Hotel");
		room1.setRommStatus("Booked");
		room1.setHotelPlace("Hyderabad");
		room1.setSpecifiedHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");

		RoomInfoBean room2 = HotelBookingFactory.getRoomInfoBeanInstance();
		room2.setRoomNo(122);
		room2.setRoomType("Classic-Room");
		room2.setRoomPrice(10000);
		room2.setHotelCode(1);
		room2.setRoomSpecifiedHotel("Taj Hotel");
		room2.setRommStatus("Available");
		room2.setHotelPlace("Hyderabad");
		room2.setSpecifiedHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");

		RoomInfoBean room3 = HotelBookingFactory.getRoomInfoBeanInstance();
		room3.setRoomNo(123);
		room3.setRoomType("Classic-Room");
		room3.setRoomPrice(10000);
		room3.setHotelCode(1);
		room3.setRoomSpecifiedHotel("Taj Hotel");
		room3.setRommStatus("Available");
		room3.setHotelPlace("Hyderabad");
		room3.setSpecifiedHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");

		RoomInfoBean room4 = HotelBookingFactory.getRoomInfoBeanInstance();
		room4.setRoomNo(124);
		room4.setRoomType("Classic-Room");
		room4.setRoomPrice(10000);
		room4.setHotelCode(1);
		room4.setRoomSpecifiedHotel("Taj Hotel");
		room4.setRommStatus("Available");
		room4.setHotelPlace("Hyderabad");
		room4.setSpecifiedHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");

		RoomInfoBean room5 = HotelBookingFactory.getRoomInfoBeanInstance();
		room5.setRoomNo(125);
		room5.setRoomType("Duplex-Room");
		room5.setRoomPrice(15000);
		room5.setHotelCode(1);
		room5.setRoomSpecifiedHotel("Taj Hotel");
		room5.setRommStatus("Booked");
		room5.setHotelPlace("Hyderabad");
		room5.setSpecifiedHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");

		RoomInfoBean room6 = HotelBookingFactory.getRoomInfoBeanInstance();
		room6.setRoomNo(126);
		room6.setRoomType("Duplex-Room");
		room6.setRoomPrice(15000);
		room6.setHotelCode(1);
		room6.setRoomSpecifiedHotel("Taj Hotel");
		room6.setRommStatus("Available");
		room6.setHotelPlace("Hyderabad");
		room6.setSpecifiedHotellocation("1-44-21/25 Plato-building, Begaumpet, Hyderabad");

		RoomInfoBean room7 = HotelBookingFactory.getRoomInfoBeanInstance();
		room7.setRoomNo(1221);
		room7.setRoomType("Classic-Room");
		room7.setRoomPrice(8000);
		room7.setHotelCode(2);
		room7.setRoomSpecifiedHotel("Hotel Vivantha");
		room7.setRommStatus("Booked");
		room7.setHotelPlace("Hyderabad");
		room7.setSpecifiedHotellocation("1-22/25 Vishwa-Bhavan, Madhapur, Hyderabad");

		RoomInfoBean room8 = HotelBookingFactory.getRoomInfoBeanInstance();
		room8.setRoomNo(1222);
		room8.setRoomType("Classic-Room");
		room8.setRoomPrice(8000);
		room8.setHotelCode(2);
		room8.setRoomSpecifiedHotel("Hotel Vivantha");
		room8.setRommStatus("Available");
		room8.setHotelPlace("Hyderabad");
		room8.setSpecifiedHotellocation("1-22/25 Vishwa-Bhavan, Madhapur, Hyderabad");

		RoomInfoBean room9 = HotelBookingFactory.getRoomInfoBeanInstance();
		room9.setRoomNo(1223);
		room9.setRoomType("Duplex-Room");
		room9.setRoomPrice(12000);
		room9.setHotelCode(2);
		room9.setRoomSpecifiedHotel("Hotel Vivantha");
		room9.setRommStatus("Available");
		room9.setHotelPlace("Hyderabad");
		room9.setSpecifiedHotellocation("1-22/25 Vishwa-Bhavan, Madhapur, Hyderabad");

		RoomInfoBean room10 = HotelBookingFactory.getRoomInfoBeanInstance();
		room10.setRoomNo(1224);
		room10.setRoomType("Duplex-Room");
		room10.setRoomPrice(12000);
		room10.setHotelCode(2);
		room10.setRoomSpecifiedHotel("Hotel Vivantha");
		room10.setRommStatus("Available");
		room10.setHotelPlace("Hyderabad");
		room10.setSpecifiedHotellocation("1-22/25 Vishwa-Bhavan, Madhapur, Hyderabad");

		RoomInfoBean room11 = HotelBookingFactory.getRoomInfoBeanInstance();
		room11.setRoomNo(111);
		room11.setRoomType("Classic-Room");
		room11.setRoomPrice(11000);
		room11.setHotelCode(1);
		room11.setRoomSpecifiedHotel("Maroit Hotel");
		room11.setRommStatus("Booked");
		room11.setHotelPlace("Bangalore");
		room11.setSpecifiedHotellocation("15/211-12 Kanchana Bavan, Anandarao Circle, Bangalore");

		RoomInfoBean room12 = HotelBookingFactory.getRoomInfoBeanInstance();
		room12.setRoomNo(112);
		room12.setRoomType("Duplex-Room");
		room12.setRoomPrice(16000);
		room12.setHotelCode(1);
		room12.setRoomSpecifiedHotel("Mariot Hotel");
		room12.setRommStatus("Available");
		room12.setHotelPlace("Bangalore");
		room12.setSpecifiedHotellocation("15/211-12 Kanchana Bavan, Anandarao Circle, Bangalore");

		RoomInfoBean room13 = HotelBookingFactory.getRoomInfoBeanInstance();
		room13.setRoomNo(201);
		room13.setRoomType("Classic-Room");
		room13.setRoomPrice(9000);
		room13.setHotelCode(2);
		room13.setRoomSpecifiedHotel("The Hotel Vpark");
		room13.setRommStatus("Available");
		room13.setHotelPlace("Bangalore");
		room13.setSpecifiedHotellocation("12-22/123 Mithra-Building,Basavan gudi, bangalore");

		RoomInfoBean room14 = HotelBookingFactory.getRoomInfoBeanInstance();
		room14.setRoomNo(202);
		room14.setRoomType("Duplex-Room");
		room14.setRoomPrice(13000);
		room14.setHotelCode(2);
		room14.setRoomSpecifiedHotel("The Hotel Vpark");
		room14.setRommStatus("Booked");
		room14.setHotelPlace("Bangalore");
		room14.setSpecifiedHotellocation("12-22/123 Mithra-Building,Basavan gudi, bangalore");

		roomsList.add(room1);
		roomsList.add(room2);
		roomsList.add(room3);
		roomsList.add(room4);
		roomsList.add(room5);
		roomsList.add(room6);
		roomsList.add(room7);
		roomsList.add(room8);
		roomsList.add(room9);
		roomsList.add(room10);
		roomsList.add(room11);
		roomsList.add(room12);
		roomsList.add(room13);
		roomsList.add(room14);

	}
	int availableRoomsType1;
	int availableRoomsType2;

	public boolean roomsCheckingAvailability(String hotelName) {

		int type1Rooms = 0;
		int type2rooms = 0;
		int count = 0;
		logger.info("---------------- Available rooms ------------------");
		logger.info("Room Num" + "    " + "Room Type" + "    " + " Room price");
		for (RoomInfoBean roominfobean : roomsList) {
			if (roominfobean.getRommStatus().equals("Available")
					&& roominfobean.getRoomSpecifiedHotel().equals(hotelName)) {
				count++;

				if (roominfobean.getRoomType().equals("Classic-Room")) {
					type1Rooms++;
				} else {
					type2rooms++;
				}
				logger.info(roominfobean.getRoomNo() + "         " + roominfobean.getRoomType() + "          "
						+ roominfobean.getRoomPrice() + "/-");
			}
		}
		availableRoomsType1 = type1Rooms;
		availableRoomsType2 = type2rooms;

		logger.info("======================================================");
		logger.info("1.Classic rooms available = " + type1Rooms);
		logger.info("2.Duplex  rooms available = " + type2rooms);
		logger.info("======================================================");

		if (count == 0) {

			System.err.println("Sorry rooms not Available at this Moment");
			return false;
		} else {

			return true;
		}

	}

	public boolean roomSelection(String hotelName) {

		BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();
		L: do {

			logger.info("Select type of room you want");
			logger.info("1.Classic-room(Allowed 3 persons per room)");
			logger.info("2.Duplex-room(Allowed 4 persons per room)");
			logger.info("3.Back");

			String numberss = sc.next();
			while (!inputvalidation.selectinValidation(numberss)) {
				logger.info("please enter valid choice [1-3]");
				numberss = sc.nextLine();
			}
			int selectionNum = Integer.parseInt(numberss);

			switch (selectionNum) {

			case 1:
				logger.info("Room Facilities :  \nAC             Fan\nKitchen        Gyeser\nTV             WIFI");
				logger.info("Enter number of rooms you want");

				String roomsYouNeed = sc.next();
				while (!inputvalidation.hotelCodeValidate(roomsYouNeed)) {
					logger.info("Enter valid like [1-2 digits]");
					roomsYouNeed = sc.nextLine();
				}

				int roomsYouNeed1 = Integer.parseInt(roomsYouNeed);

				try {
					if (roomsYouNeed1 <= availableRoomsType1) {

						M: for (RoomInfoBean roominfobean : roomsList) {
							if (roominfobean.getRoomSpecifiedHotel().equals(hotelName)
									&& roominfobean.getRommStatus().equals("Available")) {

								if (roominfobean.getRoomType().equals("Classic-Room")) {

									bookingdao.insertBooking(roominfobean, roomsYouNeed1);
									break M;
								}
							}
						}
					} else {
						throw new RoomDetailsNotFoundException("Entered Number of Rooms Not Available At this Moment");
					}
				} catch (RoomDetailsNotFoundException e) {
					System.err.println(e.getMessage1());
				}
				break L;

			case 2:
				logger.info("Room Facilities :  \nAC             Fan\nKitchen        Gyeser\nTV             WIFI");
				logger.info("Enter no of rooms you want");
				String roomsYouWant = sc.next();
				while (!inputvalidation.hotelCodeValidate(roomsYouWant)) {
					logger.info("Enter valid code like [1-2 digits]");
					roomsYouWant = sc.nextLine();
				}
				int roomsYouWant1 = Integer.parseInt(roomsYouWant);
				try {
					if (roomsYouWant1 <= availableRoomsType2) {
						M: for (RoomInfoBean roominfobean : roomsList) {
							if (roominfobean.getRoomSpecifiedHotel().equals(hotelName)
									&& roominfobean.getRommStatus().equals("Available")) {

								if (roominfobean.getRoomType().equals("Duplex-Room")) {

									bookingdao.insertBooking(roominfobean, roomsYouWant1);
									break M;
								}
							}
						}
					} else {
						throw new RoomDetailsNotFoundException("ENTERED NUMBER OF ROOMS NOT AVAILABLE AT THID MOMENT");
					}
				} catch (RoomDetailsNotFoundException e) {
					System.err.println(e.getMessage1());
				}
				break L;

			case 3:
				break L;
			}

		} while (true);

		return true;

	}

	public boolean setRoomUpdate(int roomNo) {
		for (RoomInfoBean roominfobean : roomsList) {
			if (roominfobean.getRoomNo() == roomNo) {
				roominfobean.setRommStatus("Booked");
			}
		}

		return true;

	}

	public boolean getRoomDetails() {

		int check = 0;
		logger.info("Enter hotel Name");
		String hotelName = sc.nextLine();
		while (!inputvalidation.fullNameValidate(hotelName)) {
			logger.info("Please enter valid name like [Hotel Swetha]");
			hotelName = sc.nextLine();
		}

		logger.info("Enter room Number");
		String roomNor = sc.nextLine();
		while (!inputvalidation.rmNumberValidate(roomNor)) {
			logger.info("Please enter valid name like [1-5 Digits]");
			roomNor = sc.nextLine();
		}

		int nor = Integer.parseInt(roomNor);
		for (RoomInfoBean roominfobean : roomsList) {
			if (roominfobean.getRoomNo() == nor && roominfobean.getRoomSpecifiedHotel().equals(hotelName)) {
				logger.info(roominfobean);
				check++;
			}
		}

		try {
			if (check == 0) {
				throw new RoomDetailsNotFoundException("NO ROOM DETAILS FOUND");
			} else {
				logger.info("=========================================");
			}
		} catch (RoomDetailsNotFoundException e) {
			System.err.println(e.getMessage1());
		}
		return true;
	}

	public boolean addRoom(RoomInfoBean roominfobean) {

		ArrayList<RoomInfoBean> list = new ArrayList<RoomInfoBean>();
		int size = roomsList.size();
		int count = 0;
		String location1 = "Hyderabad";
		String location2 = "Bangalore";

		logger.info("Please add room to Enter details");

		logger.info("Please enter Hotel Location");
		String locations = sc.nextLine();
		while (!inputvalidation.nameValidation(locations)) {
			logger.info("Please Enter valid hotel name like [Hyderabad' or'Bangalore]");
			locations = sc.nextLine();
		}

		while (!(location1.equals(locations) || location2.equals(locations))) {
			logger.info("please enter location like  [Hyderabad' or'Bangalore]");
			locations = sc.nextLine();

			while (!inputvalidation.nameValidation(locations)) {
				logger.info("Please enter valid location like [Hyderabad' or'Bangalore]");
				locations = sc.nextLine();
			}
		}
		logger.info("Please Enter Hotel Name");
		String hotelnme = sc.nextLine();
		while (!inputvalidation.fullNameValidate(hotelnme)) {
			logger.info("Please Enter valid hotel name like [Hotel Swetha]");
			hotelnme = sc.nextLine();
		}
		L: for (RoomInfoBean roominfobean1 : roomsList) {

			if (roominfobean1.getHotelPlace().equals(locations)
					&& roominfobean1.getRoomSpecifiedHotel().equals(hotelnme)) {
				count++;
				logger.info("Request done to Add Room in this Location");
				logger.info("Please enter room number");
				String roomnumr = sc.nextLine();
				while (!inputvalidation.rmNumberValidate(roomnumr)) {
					logger.info("Enter valid room number  like [1-5 Digits]");
					roomnumr = sc.nextLine();
				}
				int roomnumber = Integer.parseInt(roomnumr);

				for (RoomInfoBean hotelinfobean : roomsList) {
					while (hotelinfobean.getRoomNo() == roomnumber
							&& hotelinfobean.getRoomSpecifiedHotel().equals(hotelnme)) {
						logger.info("This room number Already Exist Try Different");
						roomnumr = sc.nextLine();
						roomnumber = Integer.parseInt(roomnumr);
						while (!inputvalidation.rmNumberValidate(roomnumr)) {
							logger.info("please enter valid farmat should be [1-5 Digits]");
							roomnumr = sc.nextLine();
						}
						roomnumber = Integer.parseInt(roomnumr);
					}

				}

				logger.info("Enter Hotel Code ");
				String hotelCode = sc.nextLine();
				while (!inputvalidation.hotelCodeValidate(hotelCode)) {
					logger.info("Enter valid code like [1-2 digits]");
					hotelCode = sc.nextLine();
				}
				int code = Integer.parseInt(hotelCode);

				logger.info("Enter type of Room ");
				String roomtype = sc.nextLine();
				while (!inputvalidation.roomtypeValidate(roomtype)) {
					logger.info("Enter valid Type like [Classic-Room or Duplex-Room]");
					roomtype = sc.nextLine();
				} 
				while (!("Classic-Room").equals(roomtype) || ("Duplex-Room").equals(roomtype)){
					logger.info("please enter room type should be [Classic-Room or Duplex-Room]");
					roomtype = sc.nextLine();

					while (!inputvalidation.roomtypeValidate(roomtype)) {
						logger.info("Please enter valid room type should be [Classic-Room or Duplex-Room]");
						roomtype = sc.nextLine();
					}
				}


				logger.info("Enter price of Room price");
				String rmprice = sc.nextLine();
				while (!inputvalidation.salaryValidate(rmprice)) {
					logger.info("enter valid price like [1-5 digits]");
					rmprice = sc.nextLine();
				}

				logger.info("Enter addres of hotel");
				String address = sc.nextLine();
				while (!inputvalidation.addressValidate(address)) {
					logger.info("enter valid address like [panjagutta, hyderabad]");
					address = sc.nextLine();
				}

				logger.info("Enter Room Status");
				String status = sc.nextLine();
				while (!inputvalidation.nameValidation(status)) {
					logger.info("enter valid status like [Available]");
					status = sc.nextLine();
				}

				int rooprice = Integer.parseInt(rmprice);
				roominfobean.setRoomNo(roomnumber);
				roominfobean.setHotelPlace(locations);
				roominfobean.setSpecifiedHotellocation(address);
				roominfobean.setRoomSpecifiedHotel(hotelnme);
				roominfobean.setRoomType(roomtype);
				roominfobean.setRoomPrice(rooprice);
				roominfobean.setHotelCode(code);
				roominfobean.setRommStatus(status);
				roominfobean.setSpecifiedHotellocation(address);

				break L;
			}
		}
		try {
			list.add(roominfobean);
			roomsList.addAll(list);
			if (count == 0) {
				throw new RoomDetailsNotFoundException("ROOM DETAILS NOT ADDED");
			} else {
				logger.info("Room Details added successfully");

			}
		} catch (RoomDetailsNotFoundException e) {
			System.err.println(e.getMessage1());
		}

		return true;
	}

	public boolean updateRoom(RoomInfoBean roominfobean1) {

		int count = 0;
		String location1 = "Hyderabad";
		String location2 = "Bangalore";
		logger.info("Please update room details");
		logger.info("Please enter Hotel Location");
		String locations = sc.nextLine();
		while (!inputvalidation.nameValidation(locations)) {
			logger.info("Please Enter valid hotel name like [Hyderabad' or'Bangalore]");
			locations = sc.nextLine();
		}

		while (!(location1.equals(locations) || location2.equals(locations))) {
			logger.info("please enter location like  [Hyderabad' or'Bangalore]");
			locations = sc.nextLine();

			while (!inputvalidation.nameValidation(locations)) {
				logger.info("Please enter valid location like [Hyderabad' or'Bangalore]");
				locations = sc.nextLine();
			}
		}

		logger.info("Please Enter Hotel Name");
		String hotelnme = sc.nextLine();
		while (!inputvalidation.fullNameValidate(hotelnme)) {
			logger.info("Please Enter valid hotel name like [Hotel Swetha]");
			hotelnme = sc.nextLine();
		}
		logger.info("Enter room number");
		String roomnum = sc.nextLine();
		while (!inputvalidation.rmNumberValidate(roomnum)) {
			logger.info("Enter Valid number like [1-5 Digits]");
			roomnum = sc.nextLine();
		}
		int roomn = Integer.parseInt(roomnum);

		for (RoomInfoBean roominfo : roomsList) {
			if (roominfo.getRoomNo() == roomn && roominfo.getRoomSpecifiedHotel().equals(hotelnme)
					&& roominfo.getHotelPlace().equals(locations)) {

				count++;
				logger.info("Request is Done ");
				logger.info("update details");

				logger.info("Please enter room number");
				String roomnumr = sc.nextLine();
				while (!inputvalidation.rmNumberValidate(roomnumr)) {
					logger.info("Enter valid room number  like [1-5 Digits]");
					roomnumr = sc.nextLine();
				}
				int roomnumber = Integer.parseInt(roomnumr);

				for (RoomInfoBean roominfobean : roomsList) {
					while (roominfobean.getRoomSpecifiedHotel().equals(hotelnme)
							&& roominfobean.getRoomNo() == roomnumber) {
						logger.info("This Room number Already Exist Try Different");
						roomnumr = sc.nextLine();
						roomnumber = Integer.parseInt(roomnumr);
						while (!inputvalidation.rmNumberValidate(roomnumr)) {
							logger.info("please enter valid farmat should be [1-5 Digits]");
							roomnumr = sc.nextLine();
						}
						roomnumber = Integer.parseInt(roomnumr);
					}

				}

				logger.info("Enter Hotel number ");
				String hotelCode = sc.nextLine();
				while (!inputvalidation.hotelCodeValidate(hotelCode)) {
					logger.info("Enter valid price like [1-2 Digits]");
					hotelCode = sc.nextLine();
				}
				int code = Integer.parseInt(hotelCode);

				logger.info("Enter type of Room ");
				String roomtype = sc.nextLine();
				while (!inputvalidation.roomtypeValidate(roomtype)) {
					logger.info("Enter valid Type should be [Classic-Room or Duplex-Room]");
					roomtype = sc.nextLine();
				} 
				
				while (!("Classic-Room").equals(roomtype) || ("Duplex-Room").equals(roomtype)){
					logger.info("please enter room type should be [Classic-Room or Duplex-Room]");
					roomtype = sc.nextLine();

					while (!inputvalidation.roomtypeValidate(roomtype)) {
						logger.info("Please enter valid room type should be [Classic-Room or Duplex-Room]");
						roomtype = sc.nextLine();
					}
				}


				logger.info("Enter price of room ");
				String rmprice = sc.nextLine();
				while (!inputvalidation.salaryValidate(rmprice)) {
					logger.info("Enter valid price like [1-7 digits]");
					rmprice = sc.nextLine();
				}
				logger.info("Enter addres ");
				String address = sc.nextLine();
				while (!inputvalidation.addressValidate(address)) {
					logger.info("Enter valid address like [panjagutta, hyderabad]");
					address = sc.nextLine();
				}

				int rooprice = Integer.parseInt(rmprice);
				roominfo.setRoomNo(roomnumber);
				roominfo.setHotelPlace(locations);
				roominfo.setRoomSpecifiedHotel(hotelnme);
				roominfo.setRoomType(roomtype);
				roominfo.setRoomPrice(rooprice);
				roominfo.setHotelCode(code);
				roominfo.setSpecifiedHotellocation(address);

			}
		}
		try {
			if (count == 0) {
				throw new RoomDetailsNotFoundException("NO DATA FOUND TO UPDATE DETAILS");
			} else {
				logger.info("Room Details updated successfully");

			}
		} catch (RoomDetailsNotFoundException e) {
			System.err.println(e.getMessage1());
		}
		return true;
	}

	public boolean deleteRoom() {
		int check = 0;
		logger.info("Enter hotel Name");
		String hotelName = sc.nextLine();
		while (!inputvalidation.fullNameValidate(hotelName)) {
			logger.info("Please enter valid name like [Hotel Swetha]");
			hotelName = sc.nextLine();
		}

		logger.info("Enter room Number");
		String roomNor = sc.nextLine();
		while (!inputvalidation.rmNumberValidate(roomNor)) {
			logger.info("Please enter valid name like [1-5 digits]");
			roomNor = sc.nextLine();
		}

		int nor = Integer.parseInt(roomNor);
		Iterator<RoomInfoBean> roombean = roomsList.iterator();
		while (roombean.hasNext()) {

			RoomInfoBean str = roombean.next();
			if (str.getRoomNo() == nor && str.getRoomSpecifiedHotel().equals(hotelName)) {
				check++;
				logger.info("Room found");
				roombean.remove();
			}

		}
		try {
			if (check == 0) {
				throw new RoomDetailsNotFoundException("ROOM DETAILS NOT FOUND");
			} else {
				logger.info("Room deleted Successfully");

			}
		} catch (RoomDetailsNotFoundException e) {
			System.err.println(e.getMessage1());

		}

		return true;
	}

	public List<RoomInfoBean> getAllRooms() {
		
		int count = 0;
		for (RoomInfoBean roominfobean : roomsList) {
			logger.info(roominfobean);
			count++;

		}
		try {
			if (count == 0) {
				throw new RoomDetailsNotFoundException("NO ROOM DETAILS FOUND");
			} else {
				logger.info("=========================================");
			}
		} catch (RoomDetailsNotFoundException e) {
			System.err.println(e.getMessage1());
		}
		return null;
	}

}
