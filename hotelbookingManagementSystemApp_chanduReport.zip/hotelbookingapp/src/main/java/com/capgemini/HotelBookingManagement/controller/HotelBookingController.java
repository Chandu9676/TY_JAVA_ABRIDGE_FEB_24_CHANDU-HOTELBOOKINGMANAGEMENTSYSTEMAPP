package com.capgemini.HotelBookingManagement.controller;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;
import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.service.Admin;
import com.capgemini.HotelBookingManagement.service.EmployeeManagement;
import com.capgemini.HotelBookingManagement.service.ServiceCustomer;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class HotelBookingController {
	static final Logger logger = Logger.getLogger(HotelBookingController.class);

	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {

		InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
		logger.info("======= WELL COME TO HOTEL BOOKING MANAGEMENT SYSTEM ========");
		logger.info("select options bellow");

		P: do {
			
			logger.info("1.Customer ");
			logger.info("2.Hotel Management");
			logger.info("3.Admin");
			logger.info("4.Exit");

			String choice = scan.nextLine();
			while (!inputvalidation.choiceValidate(choice)) {
				logger.info("Invalid choice please Re-Enter [1-4] ");
				choice = scan.nextLine();
			}
			int num = Integer.parseInt(choice);
			switch (num) {

			case 1:
				ServiceCustomer service = HotelBookingFactory.getServiceInstance();
				service.getCustromerRegistration(new CutomerInfoBean());
				break;
			case 2:
				EmployeeManagement employee = HotelBookingFactory.getEmployeeImplInstance();
				employee.employeeRegistration(new EmployeeInfoBean());
				break;
			case 3:
				Admin admin = HotelBookingFactory.getAdminImplInstance();
				try {
					admin.startAdminWorks();
				} catch (Exception e) {
					System.err.println(e.getMessage());
				}
				break;
			case 4:
				break P;
			default:
				logger.info("please enter valid choice (1-4)");
				break;
			}
		} while (true);

		logger.info("-------- THANKS FOR USING ---------");
	}

}
