package com.capgemini.HotelBookingManagement.exceptions;

@SuppressWarnings("serial")
public class RoomDetailsNotFoundException extends Exception {
	String messages = "Details Not Found";

	public RoomDetailsNotFoundException(String msg) {
		super();
		this.messages = msg;
	}

	public String getMessage1() {
		return messages;

	}
}
