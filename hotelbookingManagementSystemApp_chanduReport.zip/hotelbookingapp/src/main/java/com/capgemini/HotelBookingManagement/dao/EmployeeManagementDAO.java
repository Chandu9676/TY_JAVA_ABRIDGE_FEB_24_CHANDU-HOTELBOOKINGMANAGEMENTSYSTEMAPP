package com.capgemini.HotelBookingManagement.dao;

import java.util.List;

import com.capgemini.HotelBookingManagement.bean.EmployeeInfoBean;

public interface EmployeeManagementDAO {

	public boolean addEmployee(EmployeeInfoBean employee);

	public boolean updateEmployee(EmployeeInfoBean employeeinfo);

	public boolean deleteEmployee();

	public List<EmployeeInfoBean> getAllEmployee();
	
	public boolean getEmployee();

	public boolean getEmployeeLogin();

	public boolean getCustomerOperations();

	public boolean getBookingOperations();

}


