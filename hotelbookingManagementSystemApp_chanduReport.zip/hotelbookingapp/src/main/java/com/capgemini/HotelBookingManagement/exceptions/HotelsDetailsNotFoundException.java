package com.capgemini.HotelBookingManagement.exceptions;

@SuppressWarnings("serial")
public class HotelsDetailsNotFoundException extends Exception {
	String message ;

	public HotelsDetailsNotFoundException(String msg) {
		this.message = msg;
	}

	public String Getmessages() {
		return message;
	}
}
