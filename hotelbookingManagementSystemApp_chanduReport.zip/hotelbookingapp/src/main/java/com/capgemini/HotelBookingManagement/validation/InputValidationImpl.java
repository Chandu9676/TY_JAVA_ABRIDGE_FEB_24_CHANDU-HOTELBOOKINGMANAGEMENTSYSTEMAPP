package com.capgemini.HotelBookingManagement.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputValidationImpl implements InputValidations {

	Pattern pat = null;
	Matcher mat = null;

	public boolean choiceValidate(String choice) {
		pat = Pattern.compile("[1-4]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean idValidation(String iD) {
		pat = Pattern.compile("\\d{4,5}"); // ^[a-z0-9_-]{5,14}$"
		mat = pat.matcher(iD);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean nameValidation(String name) {
		pat = Pattern.compile("[A-Z]{1}[a-z]{4,25}");
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean userNameValidation(String userName) {
		pat = Pattern.compile("[A-Za-z]{4,15}");
		mat = pat.matcher(userName);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean emailValidation(String email) {
		pat = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
		mat = pat.matcher(email);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean passwordValidate(String password) {
		pat = Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
		mat = pat.matcher(password);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean contactValidation(String contactNumber) {
		pat = Pattern.compile("[6-9][0-9]{9}");
		mat = pat.matcher(contactNumber);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean ageValidation(String age) {
		pat = Pattern.compile("[1-9][0-9]");
		mat = pat.matcher(age);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean selectinValidation(String selection) {
		pat = Pattern.compile("[1-3]");
		mat = pat.matcher(selection);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean selectionsValidation(String selection) {
		pat = Pattern.compile("[1-6]");
		mat = pat.matcher(selection);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean dateValidation(String date) {
		pat = Pattern.compile("^((19|2[0-9])[0-9]{2})-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$");
		mat = pat.matcher(date);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean salaryValidate(String salary) {
		pat = Pattern.compile("\\d{1,7}");
		mat = pat.matcher(salary);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean fullNameValidate(String name) {
		pat = Pattern.compile("[[A-za-z]+\\s]{4,35}");
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean rmNumberValidate(String no) {
		pat = Pattern.compile("\\d{1,5}");
		mat = pat.matcher(no);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean addressValidate(String addres) {
		pat = Pattern.compile("[\\w+\\s+\\W]{6,200}");
		mat = pat.matcher(addres);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	} 
	public boolean discValidate(String addres) {
		pat = Pattern.compile("[\\w+\\s+\\W]");
		mat = pat.matcher(addres);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean roomtypeValidate(String type) {
		pat = Pattern.compile("[[A-Z]{1}[a-z]{4,30}+-]*");
		mat = pat.matcher(type);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean cardValidate(String nor) {
		pat = Pattern.compile("[1-9][0-9]{11}");
		mat = pat.matcher(nor);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean cvvValidate(String cvv) {

		pat = Pattern.compile("[0-9]{3}");
		mat = pat.matcher(cvv);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean oTPValidate(String otp) {

		pat = Pattern.compile("[0-9]{6}");
		mat = pat.matcher(otp);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean hotelCodeValidate(String nor) {
		pat = Pattern.compile("\\d{1,2}");
		mat = pat.matcher(nor);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}

	public boolean hotelNumberValidate(String nors) {
		pat = Pattern.compile("[0-9]{2}");
		mat = pat.matcher(nors);
		if (mat.matches()) {
			return true;
		} else {
			return false;
		}
	}
}
