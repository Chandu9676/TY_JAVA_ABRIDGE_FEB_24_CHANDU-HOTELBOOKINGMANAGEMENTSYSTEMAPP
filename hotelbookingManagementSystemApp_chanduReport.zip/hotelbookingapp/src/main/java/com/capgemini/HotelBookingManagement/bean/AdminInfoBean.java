package com.capgemini.HotelBookingManagement.bean;

public class AdminInfoBean {
	private int adminID;
	private String adminName;
	private long adminMobile;
	private String password;

	public int getAdminID() {
		return adminID;
	}

	public void setAdminID(int adminID) {
		this.adminID = adminID;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public long getAdminMobile() {
		return adminMobile;
	}

	public void setAdminMobile(long adminMobile) {
		this.adminMobile = adminMobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
