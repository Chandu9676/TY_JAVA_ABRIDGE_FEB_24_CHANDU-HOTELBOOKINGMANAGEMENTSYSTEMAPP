package com.capgemini.HotelBookingManagement.bean;

public class HotelInfoBean {

	private String hotelName;
	private String location;
	private String hotelMail;
	private long hotelMobile;
	private String hotellocation;
	private String hotelDescription;
	private int hotelnumber;
	
	
	

	public int getHotelnumber() {
		return hotelnumber;
	}

	public void setHotelnumber(int hotelnumber) {
		this.hotelnumber = hotelnumber;
	}

	public String getHotelDescription() {
		return hotelDescription;
	}

	public void setHotelDescription(String hotelDescription) {
		this.hotelDescription = hotelDescription;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getHotelMail() {
		return hotelMail;
	}

	public void setHotelMail(String hotelMail) {
		this.hotelMail = hotelMail;
	}

	public long getHotelMobile() {
		return hotelMobile;
	}

	public void setHotelMobile(long hotelMobile) {
		this.hotelMobile = hotelMobile;
	}
	
	/**
	 * @return the hotellocation
	 */
	public String getHotellocation() {
		return hotellocation;
	}

	/**
	 * @param hotellocation the hotellocation to set
	 */
	public void setHotellocation(String hotellocation) {
		this.hotellocation = hotellocation;
	}

	public String toString() {
		return "Hotel Number = " + hotelnumber + "   Hotel Name = " + hotelName + "   Hotel Location = " + location + "   Hotel Mail = " + hotelMail
				+ "   Hotel mobile = " + hotelMobile + "\n";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HotelInfoBean other = (HotelInfoBean) obj;
		if (hotelMail == null) {
			if (other.hotelMail != null)
				return false;
		} else if (!hotelMail.equals(other.hotelMail))
			return false;
		if (hotelMobile != other.hotelMobile)
			return false;
		if (hotelName == null) {
			if (other.hotelName != null)
				return false;
		} else if (!hotelName.equals(other.hotelName))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		return true;
	}
	
	
}
