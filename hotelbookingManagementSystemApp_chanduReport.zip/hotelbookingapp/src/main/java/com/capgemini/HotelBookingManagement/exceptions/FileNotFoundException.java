package com.capgemini.HotelBookingManagement.exceptions;

@SuppressWarnings("serial")
public class FileNotFoundException extends Exception {
	String msg = "FILE NOT FOUND";

	public String getMessage() {
		return msg;
	}
}
