package com.capgemini.HotelBookingManagement.service;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.HotelBookingManagement.controller.HotelBookingController;
import com.capgemini.HotelBookingManagement.dao.AdminDAO;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.validation.InputValidations;

public class AdminImpl implements Admin {

	static final Logger logger = Logger.getLogger(HotelBookingController.class);
	InputValidations inputvalidation = HotelBookingFactory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);

	public boolean startAdminWorks() throws Exception {

		AdminDAO admindao = HotelBookingFactory.getAdminDAOImplInstance();
		boolean successful = admindao.getAdminLogin();
		if (successful == true) {
			M: do {
				logger.info("Select options bellow");
				logger.info("1.Employee management related operations");
				logger.info("2.Hotel related operations");
				logger.info("3.Rooms related operations");
				logger.info("4.Reports operations");
				logger.info("5.Logout");

				String choice = sc.nextLine();
				while (!inputvalidation.selectionsValidation(choice)) {
					logger.info("Invalid choice please Re-Enter ");
					choice = sc.nextLine();
				}
				int num = Integer.parseInt(choice);
				switch (num) {

				case 1:
					admindao.getEmployeeOparations();
					break;
				case 2:
					admindao.getHotelOparations();
					break;
				case 3:
					admindao.getRoomsOparations();
					break;
				case 4:
					admindao.getReportsOparations();
					break;
				case 5:
					break M;
				default:
					logger.info("please enter valid choice");
				}

			} while (true);

		}

		return true;
	}
}
