package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class RoomDAOImplTest {
	static RoomDAO roomdaoimpl = HotelBookingFactory.getRoomDAOImplInstance();
	static HotelDAO hoteldao = HotelBookingFactory.getHotelDAOImplInstance();

	static List<RoomInfoBean> roomsList = new ArrayList<RoomInfoBean>();
	
	
	@Test
	@BeforeAll
	static void testGetAllRooms() {
		assertNotNull(roomdaoimpl.getAllRooms());
	}

	@Test
	void testRoomsCheckingAvailability() {
		assertEquals(true, roomdaoimpl.roomsCheckingAvailability("Taj Hotel"));
	}

	@Test
	void testRoomSelection() {
		assertEquals(true, roomdaoimpl.roomSelection("Hotel Vivantha"));
	}

	@Test
	void testSetRoomUpdate() {
		assertEquals(true, roomdaoimpl.setRoomUpdate(121));
	}

	@Test
	void testGetRoomDetails() {
		assertEquals(true, roomdaoimpl.getRoomDetails());
	}

	@Test
	void testAddRoom() {
		assertEquals(true, roomdaoimpl.addRoom(new RoomInfoBean()));
	}

	@Test
	void testUpdateRoom() {
		assertEquals(true, roomdaoimpl.updateRoom(new RoomInfoBean()));
	}

	@Test
	void testDeleteRoom() {
		assertEquals(true, roomdaoimpl.deleteRoom());
		
	}

	
}
