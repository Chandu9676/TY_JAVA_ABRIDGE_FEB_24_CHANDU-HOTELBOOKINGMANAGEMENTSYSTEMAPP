package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.bean.BookingInfoBean;
import com.capgemini.HotelBookingManagement.bean.RoomInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class BookingDAOImplTest {
	
	static List<BookingInfoBean> bookingList = new ArrayList<BookingInfoBean>();
	static BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();
	static RoomDAO roomdaoimpl = HotelBookingFactory.getRoomDAOImplInstance();

	
	@Test
	@BeforeAll
	static void testGetAllBookingsDetails() {
		assertNotNull( bookingdao.getAllBookingsDetails());
	}
	@Test
	void testInsertBooking() {
		assertNotNull(bookingdao.insertBooking(new RoomInfoBean(), 2));
	
	}

	@Test
	void testGetGuestListSpecifiedHotel() {
		assertEquals(true, bookingdao.getGuestListSpecifiedHotel("Taj Hotel"));
	}

	@Test
	void testGetBookingSpecifiedDate() {
		assertEquals(true, bookingdao.getBookingSpecifiedDate());
	}

	

	@Test
	void testGetBookingDetailsforCustomer() {
		assertEquals(true, bookingdao.getBookingDetailsforCustomer());
	}

	@Test
	void testGetBookingSpecifiedHotel() {
		assertEquals(true, bookingdao.getBookingSpecifiedHotel("Taj Hotel"));
	}

	@Test
	void testGetBookingDetailsByEmployee() {
		assertEquals(true, bookingdao.getBookingDetailsByEmployee());
	}


	@Test
	@DisplayName("Invalid testGetGuestListSpecifiedHotel1")
	void testGetGuestListSpecifiedHotel1() {
		assertEquals(false, bookingdao.getGuestListSpecifiedHotel("Swetha Hotel"));
	}

	@Test
	@DisplayName("Invalid testGetBookingSpecifiedDate1")
	void testGetBookingSpecifiedDate1() {
		assertEquals(false, bookingdao.getBookingSpecifiedDate());
	}

	

	@Test
	@DisplayName("Invalid testGetBookingDetailsforCustomer1")
	void testGetBookingDetailsforCustomer1() {
		assertEquals(false, bookingdao.getBookingDetailsforCustomer());
	}

	@Test
	@DisplayName("Invalid testGetBookingSpecifiedHotel1")
	void testGetBookingSpecifiedHotel1() {
		assertEquals(false, bookingdao.getBookingSpecifiedHotel("Swetha Hotel"));
	}

	@Test
	@DisplayName("Invalid testGetBookingDetailsByEmployee1")
	void testGetBookingDetailsByEmployee1() {
		assertEquals(false, bookingdao.getBookingDetailsByEmployee());
	}

}
