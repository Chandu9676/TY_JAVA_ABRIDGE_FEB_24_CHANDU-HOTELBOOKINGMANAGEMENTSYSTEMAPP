package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.bean.HotelInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class HotelDAOImplTest {

	static List<HotelInfoBean> hotelList = new ArrayList<HotelInfoBean>();
	static BookingDAO bookingdao = HotelBookingFactory.getBookingDAOImplInstance();
	static RoomDAO roomdaoimpl = HotelBookingFactory.getRoomDAOImplInstance();
	static HotelDAO hoteldao = HotelBookingFactory.getHotelDAOImplInstance();

	@Test
	@BeforeAll
	static void testGetAllHotelsDetails() {
		assertNotNull(hoteldao.getAllHotelsDetails());
	}

	@Test
	void testGetListForSpecifiedHotelGuest() {
		assertEquals(true, hoteldao.getListForSpecifiedHotelGuest());
	}

	@Test
	void getHotel() {
		assertEquals(true, hoteldao.getHotel(2));
	}

	@Test
	void testAddHotel() {
		assertEquals(true, hoteldao.addHotel(new HotelInfoBean()));
	}

	@Test
	void testUpdateHotel() {
		assertEquals(true, hoteldao.updateHotel(new HotelInfoBean()));
	}

	@Test
	void testDeleteHotel() {
		assertEquals(true, hoteldao.deleteHotel());
	}

	@Test
	void testGetHotelDetails() {
		assertEquals(true, hoteldao.getHotelDetails());
	}

	@Test
	void testGetHotels() {
		assertEquals(true, hoteldao.getHotels("Hyderabad"));
	}

	@Test
	@DisplayName("Invalid getHotel1")
	void getHotel1() {
		assertEquals(false, hoteldao.getHotel(6));
	}

	@Test
	@DisplayName("Invalid testAddHotel1")
	void testAddHotel1() {
		assertEquals(false, hoteldao.addHotel(new HotelInfoBean()));
	}

	@Test
	@DisplayName("Invalid testUpdateHotel1")
	void testUpdateHotel1() {
		assertEquals(false, hoteldao.updateHotel(new HotelInfoBean()));
	}

	@Test
	@DisplayName("Invalid testDeleteHotel1")
	void testDeleteHotel1() {
		assertEquals(false, hoteldao.deleteHotel());
	}

	@Test
	@DisplayName("Invalid testGetHotelDetails1")
	void testGetHotelDetails1() {
		assertEquals(false, hoteldao.getHotelDetails());
	}

	@Test
	@DisplayName("Invalid testGetHotels1")
	void testGetHotels1() {
		assertEquals(false, hoteldao.getHotels("Mumbai"));
	}
}
