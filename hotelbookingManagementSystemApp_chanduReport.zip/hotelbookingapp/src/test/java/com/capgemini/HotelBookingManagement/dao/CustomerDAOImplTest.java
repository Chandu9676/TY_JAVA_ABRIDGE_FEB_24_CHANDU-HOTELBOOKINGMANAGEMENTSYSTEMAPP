package com.capgemini.HotelBookingManagement.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;

class CustomerDAOImplTest {
	static CutomerInfoBean customerinfo = HotelBookingFactory.getCustomerInfoInstance();
	static CustomerDAO customerdao = HotelBookingFactory.getCustomerImplInstance();

	@Test
	@DisplayName("Registration")
	@BeforeAll
	static void testGetRegistration() {
		assertNotNull(customerdao.getRegistration(customerinfo));
	}

	@Test
	
	@DisplayName("customer Login")
	 void testGetLogin() {
		assertEquals(true, customerdao.getLogin());
	}

	@Test
	@DisplayName("Booking")
	void testStartBooking() {
		assertEquals(true, customerdao.startBooking());
	}

	@Test
	@DisplayName("getCustomer")
	void testGetCustomer() {
		assertEquals(true, customerdao.getCustomer());
	}

	@Test
	@DisplayName("UpdateCustomer")
	void testUpdateCustomer() {
		assertEquals(true, customerdao.updateCustomer(customerinfo));
	}

	@Test
	@DisplayName("getAllCustomers")
	void testGetAllCustomers() {
		assertNotNull(customerdao.getAllCustomers());
	}

	@Test
	@DisplayName("GetCustomerIDForBooking")
	void testGetCustomerIDForBooking() {
		assertEquals(true,customerdao.getCustomerIDForBooking("2020"));
	}
	
	
	
	
	
	@Test
	@DisplayName("Invalid login")
	void testGetLogin1() {
		assertEquals(false, customerdao.getLogin());
	}

	@Test
	@DisplayName("Invalid getCustomer")
	void testGetCustomer1() {
		assertEquals(false, customerdao.getCustomer());
	}

	@Test
	@DisplayName("Invalid UpdateCustomer")
	void testUpdateCustomer1() {
		assertEquals(false, customerdao.updateCustomer(customerinfo));
	}
	
	@Test
	@DisplayName("Invalid GetCustomerIDForBooking")
	void testGetCustomerIDForBooking1() {
		assertEquals(false,customerdao.getCustomerIDForBooking("2050"));
	}
	
}
