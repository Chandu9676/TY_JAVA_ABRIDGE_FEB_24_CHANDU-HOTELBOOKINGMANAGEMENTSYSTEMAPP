package com.capgemini.HotelBookingManagementApp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.bean.CutomerInfoBean;
import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.service.ServiceCustomer;

public class TestServiceCustomer {


	static ServiceCustomer service = HotelBookingFactory.getServiceInstance();

	@Test

	@DisplayName("Reggistration method1")
	public void testCustomerRegistration1() {

		assertEquals(true, service.getCustromerRegistration(new CutomerInfoBean()));
	}

}
