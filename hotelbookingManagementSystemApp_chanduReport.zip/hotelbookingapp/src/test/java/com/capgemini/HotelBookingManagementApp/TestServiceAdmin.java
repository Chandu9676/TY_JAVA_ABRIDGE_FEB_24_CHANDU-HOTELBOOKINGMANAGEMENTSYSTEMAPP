package com.capgemini.HotelBookingManagementApp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.HotelBookingManagement.factory.HotelBookingFactory;
import com.capgemini.HotelBookingManagement.service.Admin;

public class TestServiceAdmin {
	static Admin service = HotelBookingFactory.getAdminImplInstance();

	@Test
	@DisplayName("AdminOperations method1")
	public void testGetAdminOperations1() throws Exception {

		assertEquals(true, service.startAdminWorks());
	}

}
